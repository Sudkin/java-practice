# CTBP5005 – CA → HK 測試 XML 說明(覆蓋 44 個 Test Case)

## 1. 結論:最少 6 份 XML

| # | 檔名 | 用途 | 一句話說明 |
|---|---|---|---|
| 01 | `01_TC-UPE-OECD1-GIR101.xml` | 有效基準檔 + 種子資料 | GIR101、6 個 GLOBEBody 全是 OECD1 |
| 02 | `02_TC-UPE-OECD1-OECD0-GIR101.xml` | GIR 計數、OECD0+新區段 | 2 個 OECD1 + 1 個 OECD0(附新 UTPRAttribution) |
| 03 | `03_TC-UPE-OECD2-GIR102.xml` | GIR102 更正計數 | 3 個 FilingInfo 全是 OECD2 |
| 04 | `04_TC-UPE-OECD2-OECD3-OECD0-GIR101.xml` | GIR101 + OECD2/OECD3 更正計數、OECD0 無區段 | OECD2 + OECD3(連 GeneralSection)+ OECD0(無區段) |
| 05 | `05_TC-UPE-OECD1-GIR101-XSDERR.xml` | XSD 驗證失敗 → Rejected | 故意放 3 個 XSD 錯誤 |
| 06 | `06_TC-UPE-OECD1-GIR101-THREAT.xml` | Threat scan | XSD 合法,但內含超連結 + script 字串 |

**為什麼不能再少?** 每一份都代表一個「別的檔案替代不了」的原因:

- **MessageTypeIndic 是整份檔一個值**:GIR101(01、02、04)和 GIR102(03)一定要分開。
- **OECD1 不能和 OECD2/OECD3 放同一份**(規則 60004),所以「新資料」的 02 和「更正/刪除」的 04 要分開。
- **OECD0(重送)只能指向已經送過的 FilingInfo**(規則 60014),所以一定要有一份先送出去的基準檔 01,02/03/04 才有東西可以引用或更正。
- **05、06 會被擋下或 Rejected**,所以不能同時當作「有效檔」使用。
- 其餘 case(檔名過濾、重複檔名、夥伴、日期、憑證、解密、檔案搬移、電郵…)只是同一次處理的不同檢查點,或是改環境設定就能測,不需要新的 XML 內容。

**這 6 份的前提**:同一份 XML 因為 MessageRefId / DocRefId 要全域唯一(60002、60007),在同一個環境只能「成功處理」一次。所以第 4 節把 case 組合成幾次執行(Run)。如果你想每個 case 獨立跑,就需要更多份「換了 ID 的有效檔」,告訴我要哪幾個 case,我再生成。

---

## 2. 命名與日期規則(照你的要求)

**MessageRefId** = 送出國 + 年 + 收件國 + `TC-角色-OECD?-GIR10?`
例:`CA2025HKTC-UPE-OECD1-GIR101`(格式同時符合規則 60001)

**DocRefId** = 送出國 + 年 + 區段名 + `TC-角色-OECD?-GIR10?`
例:`CA2025FilingInfoTC-UPE-OECD1-GIR101`

- 一份檔有多個 GLOBEBody 時,第 2 個起在區段名後面加 `B2`、`B3`…(例:`CA2025FilingInfoB2TC-UPE-OECD1-GIR101`),第 1 個不加,所以第 1 個和你給的例子完全一樣。
- **OECD0(重送)的 DocRefId 必須和原本那筆一模一樣**(規則 60014),所以 02、04 裡 OECD0 那筆的 DocRefId 是 `CA2025FilingInfoTC-UPE-OECD1-GIR101`,不會出現 `OECD0` 字樣。
- 角色全部用 UPE(GIR401):Role 不影響這 44 個 case 中任何一個;GIR403/404/405 反而會觸發規則 60019(本地申報不可交換)。

**日期**(每份 Period 為 2 天,中間隔 1 天):

| 檔 | Period Start–End | GeneralSection 的 ChangeDate(兩個 CE) | MessageSpec Timestamp |
|---|---|---|---|
| 01 | 2025-01-01 ~ 01-02 | 01-01 / 01-02 | 2025-01-02T12:00:00 |
| 02 | 2025-01-04 ~ 01-05 | 01-04 / 01-05 | 2025-01-05T12:00:00 |
| 03 | 2025-01-07 ~ 01-08 | (無 GeneralSection) | 2025-01-08T12:00:00 |
| 04 | 2025-01-10 ~ 01-11 | 01-10 / 01-11 | 2025-01-11T12:00:00 |
| 05 | 2025-01-13 ~ 01-14 | 01-13 / 01-14 | 2025-01-14T12:00:00 |
| 06 | 2025-01-16 ~ 01-17 | 01-16 / 01-17 | 2025-01-17T12:00:00 |

沿用範例:第一個 CE 的 ChangeDate = Period Start,第二個 = Period End。`ReportingPeriod` 固定 2025-12-31(Period End 不可晚於它,規則 60021)。`ElectionYear` 維持 2025-01-01(規格要求填該年第一天)。

**方向 / 內容**:`TransmittingCountry=CA`、`ReceivingCountry=HK`。內容是把你的範例 HK↔CA 互換(UPE、FilingCE 在 CA,CE 在 HK;FilingCE 的國家要等於送出國,規則 60023)。`RecJurCode` 保留範例的 HK / CA,因為每個記錄至少要有一個等於收件國 HK(規則 60018)。

---

## 3. 各 XML 內部結構與依賴

### 種子資料(01 內的 6 個 GLOBEBody)

02、03、04 只依賴 01(不互相依賴),所以 **02/03/04 放在同一次執行、任何處理順序都可以**。

| 種子 | 01 內位置 | FilingInfo DocRefId | 被誰用 |
|---|---|---|---|
| A(完整內容:GS + 2 Summary + 2 JurisdictionSection + UTPR,如你的範例) | Body 1 | `CA2025FilingInfoTC-UPE-OECD1-GIR101` | 02 Body3、04 Body3(OECD0 重送) |
| B | Body 2 | `CA2025FilingInfoB2TC-UPE-OECD1-GIR101` | 03 Body1(OECD2) |
| C | Body 3 | `…FilingInfoB3…` | 03 Body2(OECD2) |
| D | Body 4 | `…FilingInfoB4…` | 03 Body3(OECD2) |
| E | Body 5 | `…FilingInfoB5…` | 04 Body1(OECD2) |
| F(FilingInfo + GeneralSection) | Body 6 | `…FilingInfoB6…`、`CA2025GeneralSectionB6TC-UPE-OECD1-GIR101` | 04 Body2(OECD3,連 GeneralSection 一起刪,規則 60010) |

B–F 只有 FilingInfo + GeneralSection(新申報必須有 GeneralSection,規則 60017),因為它們只是給後面檔案引用的種子。

### 每份的預期計數(用規格的計數邏輯逐個 GLOBEBody 算出)

| 檔 | MessageTypeIndic | GLOBEBody | GIR_CNT | AMEND_CNT |
|---|---|---|---|---|
| 01 | GIR101 | 6 個 OECD1 | **6** | **0** |
| 02 | GIR101 | OECD1、OECD1、OECD0+UTPR(OECD1) | **2** | **1** |
| 03 | GIR102 | OECD2 ×3 | **0** | **3** |
| 04 | GIR101 | OECD2、OECD3(+GS OECD3)、OECD0(無區段) | **0** | **2** |
| 05 | GIR101 | 1 個 OECD1(有 XSD 錯誤) | 不適用(Rejected) | 不適用 |
| 06 | GIR101 | 1 個 OECD1 | 不適用(被 threat scan 擋下) | 不適用 |

### 05 的三個 XSD 錯誤(各在不同記錄,方便看錯誤表)

| 記錄 | DocRefId | 錯誤 |
|---|---|---|
| GeneralSection | `CA2025GeneralSectionTC-UPE-OECD1-GIR101-XSDERR` | `Rules=GIR299`(不在列舉值內) |
| JurisdictionSection 1 | `CA2025JurisdictionSection1TC-UPE-OECD1-GIR101-XSDERR` | 缺少必填的 `OverallComputation/ETRRate`(xmllint 會報在下一個元素 `TopUpTaxPercentage`) |
| UTPRAttribution | `CA2025UTPRAttributionTC-UPE-OECD1-GIR101-XSDERR` | `Employees=ABC`(應為整數) |

MessageSpec 是完整合法的,所以 Rejected 時系統仍讀得到 MessageRefId 來寫 header 記錄。

### 06 的 threat 內容

`FilingInfo/AdditionalInfo` 放了 CDATA:`<a href="http://malicious.example.test/payload.exe">…</a><script>alert('TC-017')</script>`。對應 Status Message 文件的 50005(超連結 / JavaScript / 執行檔)。純文字 URL 是允許的,所以我放的是 HTML 標籤形式。我**沒有**放 EICAR 病毒測試字串(會讓你的防毒把整個交付物隔離);如果你們的掃描器只認病毒特徵碼,請自行把 EICAR 字串加進 `AdditionalInfo`。

---

## 4. 執行計畫(Run)

XML 只是封包裡面的內容。zip 檔名要含 `GIR` 且副檔名 `.zip`(例:`CA_GIR_20250101T120000000Z_TC01.zip`,規格第 10 條);加密、簽章、CTS metadata 用你們現有的工具處理。

| Run | 觸發 | Inbox 內容 | 涵蓋的 Test Case |
|---|---|---|---|
| **Run 1** | 排程(週一 08:00/12:00/16:00 其中一個) | 01 的 zip + 誘餌檔 `CH_REPORT_2022.zip`、`CH_GIR_2022.txt` | 001, 003, 007, 008, 011, 013, 016, 018, 020, 021, 022, 025–028, 034, 035–037, 041 |
| **Run 2** | Ad-hoc(非排程時間,例如 10:30) | 02、03、04、05 的 zip + 一個**與 Run 1 同檔名**的 zip + 一個損壞的加密封包 | 002, 005, 006, 019, 023, 024, 029–034, 038, 040, 042, 043, 044 |
| **Run 3** | 任意 | 只放 06 的 zip | 017 |
| **特殊 Run** | 見下 | 不需新 XML | 004, 009, 010, 012, 014, 015, 039 |

**順序**:Run 1 一定要先於 Run 2(02/03/04 要引用 01 的資料;重複檔名要有 Run 1 的檔名可以撞)。特殊 Run 和 Run 3 順序不拘。

**特殊 Run 使用「01 的複本」**:這些 case 都在寫入資料庫之前就被擋下,不會消耗 01 的 ID。保險起見,複本請把 `MessageRefId` 加個尾巴(例如 `-COPY`),並用新的 zip 檔名,避免萬一系統有寫 header 記錄時撞到正式的 01。

**若環境是 Test 模式**(送 OECD0–3 會被 50008 擋下):把 `>OECD0<`~`>OECD3<` 換成 `>OECD10<`~`>OECD13<` 即可,邏輯完全對應(計數規格本來就把 1/11、2/12、3/13、0/10 視為同組):

```
sed -E 's/>OECD([0-3])</>OECD1\1</' 01_TC-UPE-OECD1-GIR101.xml > 01_test.xml
```

---

## 5. 44 個 Test Case 逐一說明

### B1 批次觸發與檔案掃描

| TC | XML | 怎麼做 | 要看什麼 |
|---|---|---|---|
| 001 | 01(Run 1) | 01 放進 `\data\cts\Inbox\`,等排程時間自動啟動 | Job 自動啟動,01 走完整流程 |
| 002 | 02/03/04(Run 2) | 非排程時間手動觸發 ad-hoc | 立即執行,處理邏輯與排程相同 |
| 003 | 01 + 誘餌(Run 1) | Inbox 同時放 GIR zip、`CH_REPORT_2022.zip`、`CH_GIR_2022.txt` | 只有 `*GIR*.zip` 被處理,另外兩個被忽略 |
| 004 | 不需要 | 清空 Inbox 後執行 | 不處理、不報錯 |
| 005 | 02、03、04(Run 2) | 三個有效 zip 同時放入 | 三份都處理完,各自產生 Status Message。**注意**:三份都是 CA 送出,「不同夥伴」需另外用不同國家 metadata 的複本才能測 |

### B2 重複檔名

| TC | XML | 怎麼做 | 要看什麼 |
|---|---|---|---|
| 006 | Run 1 檔名重放(Run 2) | Run 1 處理完後,把一個**同檔名**的 zip(內容可用 01 複本)再放入 Inbox | 移到 `\data\cts\Inbox_duplicated\`,不解壓 |
| 007 | 01(Run 1) | 全新檔名 | 不算重複,繼續解壓 / 驗證 |

### B3 夥伴與日期 / 年度

| TC | XML | 怎麼做 | 要看什麼 |
|---|---|---|---|
| 008 | 01 | CA 已登記為夥伴、系統日期在 Start/End Date 內 | 繼續解密 |
| 009 | 01 複本 | 方法 A:暫時停用 CA 夥伴設定;方法 B:複本的 sender 改成未登記的國家代碼 | 不解密、該檔不繼續處理 |
| 010 | 01 複本 | 系統日期調到夥伴 Start Date 之前(或 End Date 之後),或改夥伴日期區間 | 不進入解密 / 處理 |
| 011 | 01 | MessageRefId 是 `CA2025HK…` → data year = 2025,確認 Start/End Year 涵蓋 2025 | 繼續處理 |
| 012 | 01 複本 | 把 Start/End Year 改成不含 2025,或複本 MessageRefId 改成 `CA2019HK…` | 不當作範圍內的 GIR 處理 |

### B4 解密與憑證

| TC | XML | 怎麼做 | 要看什麼 |
|---|---|---|---|
| 013 | 01 | keystore 有 CA 的 public cert | 解密成功,進入 XSD 驗證 |
| 014 | 01 複本(單獨一次) | 把加密檔弄壞(截斷或改幾個 byte) | ZIP 進 `Inbox_invalid`,`ValidationResult='Rejected'` |
| 015 | 01 複本 | 暫時把 CA 的 cert 從 keystore 移除 | 無法解密,視為無效 / Rejected(最終落檔規格沒寫,請向 BA 確認) |

### B5 Threat scan

| TC | XML | 怎麼做 | 要看什麼 |
|---|---|---|---|
| 016 | 01 | 乾淨檔 | 通過 threat scan |
| 017 | **06**(Run 3) | 單獨放入 | 被攔截 / 隔離,沒有以 Accepted 寫入 `GIR_*` |

### B6 XSD 驗證

| TC | XML | 怎麼做 | 要看什麼 |
|---|---|---|---|
| 018 | 01 | 完全合法 | `Accepted` |
| 019 | **05**(Run 2) | 含 3 個 XSD 錯誤 | `Rejected`,錯誤詳情被記錄 |

### B7 資料庫 – Accepted

| TC | XML | 怎麼做 | 要看什麼 |
|---|---|---|---|
| 020 | 01 | 處理完查表 | `CTS_DATA_PACKET`(`MSG_TYPE='GIR'`)、`CTS_TX_REC`、`GIR_*` 有資料。01 應有 6 個 FilingInfo、6 個 GeneralSection、2 個 Summary、2 個 JurisdictionSection、1 個 UTPRAttribution |
| 021 | 01 + 05 | 對照兩檔的 `GIR_*` | 01 所有合法記錄都寫入;05 有 XSD 錯誤,`GIR_*` 不應有 05 的記錄。05 的 FilingInfo / Summary / JurisdictionSection 2 本身合法,正好可以看「合法記錄會不會被單獨寫入」——規格 §8.1 是整檔 Rejected 就不寫,若實際有寫請向 BA 確認 |
| 022 | 01 | 拿 CTS metadata 檔對照 `CTS_DATA_PACKET.META_*` | 逐欄相符(META 來自 metadata,不是 XML;`TaxYr` 對應 2025) |

### B8 資料庫 – Rejected

| TC | XML | 怎麼做 | 要看什麼 |
|---|---|---|---|
| 023 | 05 | 查表 | 有 `CTS_DATA_PACKET`、message spec、transmission;**沒有** GIR data file 記錄 |
| 024 | 05 | 查 4 張錯誤表 | `CTS_FILE_ERR`、`CTS_REC_ERR`、`CTS_ERR_FIELD`、`CTS_ERR_DOC_REF_ID` 有資料,涉及第 3 節那 3 個 DocRefId;01 的錯誤表則是空的 |

### B9 Status Message

| TC | XML | 怎麼做 | 要看什麼 |
|---|---|---|---|
| 025 | 01(Accepted)+ 05(Rejected) | 拿產出的 Status Message XML,用 `GloBE_StatusMessage_XML_Schema.md` 的 schema 驗證 | 兩種結果都通過 |
| 026 | 01 + 05 | 查表 | `CTS_DATA_PACKET`(`MSG_TYPE='GIRMessageStatus'`、`ZIP_FILENAME=NULL`)、`CTS_STS_MSG`,`SGD_STS='P'` |
| 027 | 01 + 05 | 看 `STS_MSG_REF_ID` | 格式 `Status` + `HK` + 年份 + `<Receiving Country>` + `-` + `yyyyMMddHHmmss`;年份 2025 來自 `CA2025HK…`。`<Receiving Country>` 規格沒寫清楚是 CA 還是 HK,請向 BA 確認 |
| 028 | 01 + 05 | 看輸出資料夾 | `\data\in\status_out\pending\` 下有 `<StatusMessageRefId>.xml` 和 `.metadata.xml` |

### B10 計數(UPDATED_RX_CNT)

| TC | XML | 怎麼做 | 要看什麼 |
|---|---|---|---|
| 029 | **02** | 處理後查該 MessageRefId 的 `GIR_CNT` | **2**(兩個 OECD1;OECD0 那個不算) |
| 030 | **03** | 查 `AMEND_CNT` | **3**(GIR102 每個 FilingInfo +1),`GIR_CNT`=0 |
| 031 | **04** Body1(OECD2)+ Body2(OECD3) | 查 `AMEND_CNT` | 每個 +1,共 **2**。OECD12/13 用第 4 節的 sed 轉換測 |
| 032 | **02** Body3 | OECD0 的 FilingInfo + 新的 UTPRAttribution(OECD1) | 該筆 +1,所以 02 的 `AMEND_CNT`=**1** |
| 033 | **04** Body3 | OECD0 的 FilingInfo,沒有任何區段 | 不 +1;04 的 `AMEND_CNT` 是 2 而不是 3。整份 04 也沒有任何 OECD1/11 區段,所以不論系統是逐 GLOBEBody 還是整份檢查,結果都一樣 |
| 034 | 01–04 | 呼叫 `UPDATED_RX_CNT(MessageRefID)` 後查 `GIR_MSG_SPEC` | 01: 6/0、02: 2/1、03: 0/3、04: 0/2(GIR_CNT / AMEND_CNT) |

### B11 檔案搬移

| TC | XML | 怎麼做 | 要看什麼 |
|---|---|---|---|
| 035 | Run 1 與 Run 2 的所有檔 | 處理完看資料夾 | Accepted 和 Rejected 的 ZIP 都在 `\data\cts\Inbox_recv\` |
| 036 | 同上 | 看處理後資料夾 | 解壓資料夾在 `\data\in\processed\{ZIP Filename}\` |

### B12 電郵

| TC | XML | 怎麼做 | 要看什麼 |
|---|---|---|---|
| 037 | 01 | 收信 | 標題「…containing no errors」;內容有 Send by / Message Ref ID(`CA2025HKTC-UPE-OECD1-GIR101`)/ Message Type / Transmission ID / `Result: ACCEPTED` / CTLQ5003 |
| 038 | 05 | 收信 | 標題「…containing file error(s)」;`Result: REJECTED` 及 Error Code。**注意**:規格範例寫 50002,但 Status Message 文件裡 50002 是「解密失敗」,XSD 驗證失敗是 **50007**。請以系統實際代碼為準並向 BA 確認 |
| 039 | 不需要 | 放一個根本無法處理的封包(例如 0 KB 或不是有效 zip 的 `CA_GIR_….zip`) | Fatal Error 電郵:Country / Filename / Reason |
| 040 | 02/03/04 + 05(Run 2) | 同一次執行同時有 Accepted 與 Rejected | 兩種結果各自都有寄信 |

### B13 端到端與負面路徑

| TC | XML | 怎麼做 | 要看什麼 |
|---|---|---|---|
| 041 | 01(Run 1) | 全流程 | Accepted → DB 記錄 + Status Message + 檔案搬移 + 計數更新 + Accepted 電郵;錯誤表無資料 |
| 042 | 05(Run 2) | 全流程 | Rejected → header + 錯誤表有資料、無 data file 記錄、Rejected Status Message + 電郵 |
| 043 | 損壞封包(Run 2 內) | 可用 01 複本弄壞 | 進 `Inbox_invalid`,`Rejected`,批次沒有中斷 |
| 044 | 重複檔名 zip + 損壞封包 + 02/03/04(Run 2) | 三種情況同一次執行 | 重複 → `Inbox_duplicated`;損壞 → `Inbox_invalid` + Rejected;有效 → Accepted;全部處理完並寄信 |

---

## 6. 假設與需要你留意的地方

1. **GIR101 配 OECD2/OECD3(04、TC-031)**:這是 CTBP5005 計數邏輯明文寫的組合,XSD 也允許;但 User Guide 說 GIR101「只含新資料」。如果你們系統另外嚴格執行這條業務規則,04 可能在記錄層被拒,那 TC-031 就要先向 BA 確認怎麼測。02 的組合(新資料 + OECD0 重送)符合 User Guide。
2. **OECD0 的 Period 用該檔的日期**(依你「每份日期不同」的規則),不是原 FilingInfo 的日期。規則 60014 只比對 DocRefId,不比對內容。
3. **計數邏輯的區段檢查**:規格沒寫是逐 GLOBEBody 還是整份檔檢查「有沒有 OECD1/11 區段」。02、04 的設計讓兩種實作結果一致:02 只有 Body3 是 OECD0(其餘是 OECD1,不進更正計數);04 整份沒有任何 OECD1/11 區段。
4. **財務數字沿用你的範例**,沒有改。順帶一提:範例 JurisdictionSection 1 的 `AdjustedFANIL/Total`(2146463)不等於 `FANIL + Additions − Reductions`(2646463),如果你們系統有執行規則 60028,01 和 05 會受影響;你的範例既然能跑,我就維持原樣。
5. **Currency** 維持範例的 `CAD`;**MessageSpec 的 Warning / Contact** 也維持範例。
6. **驗證過的項目**:6 份都用你提供的三個 XSD 驗證(01–04、06 通過;05 恰好 3 個預期錯誤)。另外我用 Status Message 文件的 60xxx 規則(MessageRefId / DocRefId 格式與唯一、CorrDocRefId 指向最新版本、不混用 OECD1 與 OECD2/3、OECD0 只用於 FilingInfo、RecJurCode 含 HK、Period 日期、UPE TIN 對應等)逐項檢查 01–04、06,全部通過。
7. 加密、簽章、CTS metadata、zip 打包不在 XML 範圍內,需用你們現有工具處理。
