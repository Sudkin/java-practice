# Z01–Z18 對照表（以 CTBP5005TEST21102026.xml 為底）

所有檔案：`MessageRefId` 與 7 個 `DocRefId` 都含自己的編號（Z01…Z18），彼此不重複（Z03 的 DocRefId 重複是故意的）。
`CorrDocRefId` 一律指向 **Z01** 的對應 `DocRefId`，所以 Z01 必須先被 5005 處理過。

| Z | 檔名 | MessageRefId | 與底稿的差異 | 對應 5005 case |
|---|---|---|---|---|
| Z01 | Z01_main_accepted.xml | …21102026Z01 | 只換編號 | 主線（R2） |
| Z02 | Z02_copy_for_5005-004.xml | …21102026Z02 | 只換編號 | 004（R4） |
| Z03 | Z03_duplicate_DocRefId_rejected.xml | …21102026Z03 | Summary2 的 DocRefId 與 Summary1 相同 | 012、016、021、022b、024、028、039、041（R5） |
| Z04 | Z04_copy_for_5005-013_accepted.xml | …21102026Z04 | 只換編號 | 013（R6） |
| Z05 | Z05_ReportingPeriod_mismatch_for_5005-013.xml | …21102026Z05 | ReportingPeriod=2024-12-31（MessageRefId 年度 2025） | 013（R6） |
| Z06 | Z06_for_5005-009_year_from_MessageRefId.xml | ID2025HK202609300001-Z06 | 只換 MessageRefId | 009 |
| Z07 | Z07_FilingInfo_OECD11.xml | …Z07 | FilingInfo=OECD11 | 031 |
| Z08 | Z08_all_OECD0.xml | …Z08 | FilingInfo 與 6 個區段 DocTypeIndic 全為 OECD0 | 032、036 |
| Z09 | Z09_GIR102_all_OECD2_with_CorrDocRefId.xml | …Z09 | GIR102；7 個 DocTypeIndic 全為 OECD2；各帶 CorrDocRefId | 033 |
| Z10 | Z10_GIR101_FilingInfo_OECD2.xml | …Z10 | FilingInfo=OECD2＋CorrDocRefId | 034a |
| Z11 | Z11_GIR101_FilingInfo_OECD12.xml | …Z11 | FilingInfo=OECD12＋CorrDocRefId | 034b |
| Z12 | Z12_GIR101_FilingInfo_OECD3.xml | …Z12 | FilingInfo=OECD3＋CorrDocRefId | 034c |
| Z13 | Z13_GIR101_FilingInfo_OECD13.xml | …Z13 | FilingInfo=OECD13＋CorrDocRefId | 034d |
| Z14 | Z14_FilingInfo_OECD0_GeneralSection_only.xml | …Z14 | FilingInfo=OECD0，只留 GeneralSection(OECD1) | 035 |
| Z14b（選配） | Z14b_…Summary_only_optional.xml | …Z14b | FilingInfo=OECD0，只留 1 個 Summary | 035 |
| Z14c（選配） | Z14c_…JurisdictionSection_only_optional.xml | …Z14c | FilingInfo=OECD0，只留 1 個 JurisdictionSection | 035 |
| Z14d（選配） | Z14d_…UTPRAttribution_only_optional.xml | …Z14d | FilingInfo=OECD0，只留 UTPRAttribution | 035 |
| Z15 | Z15_three_GLOBEBody_OECD1_OECD11_OECD2.xml | ID2025HK202609300001-Z15 | 3 個 GLOBEBody：FilingInfo 為 OECD1／OECD11／OECD2（第 3 個帶 CorrDocRefId）；DocRefId 後綴 Z15-B1／B2／B3 | 037 |
| Z16 | Z16_TransmittingCountry_AQ_non_partner.xml | AQ2025HKTC-…Z16 | TransmittingCountry=AQ，MessageRefId 前綴 AQ | 006、044 |
| Z17 | Z17_copy_for_5005-007.xml | …21102026Z17 | 只換編號（需另改 incoming 期間） | 007 |
| Z18 | Z18_copy_for_5005-043.xml | …21102026Z18 | 只換編號 | 043a、043b |

## 尚未驗證
- 沒有 GLOBEXML_v1.0.xsd，只確認過 XML 格式正確；是否通過加密工具的 XSD 驗證要以實跑為準。
- `stf:CorrDocRefId` 放在 `stf:DocRefId` 之後；若工具因元素順序或名稱不符而擋下，請回報 log。
- Z08～Z15 是否被 5005 判 Rejected，以及 GIR_CNT／AMEND_CNT 結果，以實測為準。
