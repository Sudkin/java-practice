# GloBE GIR XML — DESC Error Validation Test Case Document

**Project**: GloBE (Pillar Two) GIR XML Schema Validation Testing
**Schema Version**: GIR XML Schema v1.0 (OECD 2024)
**Receiving Jurisdiction**: Hong Kong (HK)
**Baseline XML**: GLOBE_BASELINE_COMPLEX.xml
**Document Scope**: Comprehensive positive and negative test cases for DESC validation rules
**Current Year** (for ReportingPeriod checks): 2026

> **Legend**
> - ✓ PASS — File should be accepted; no error fired
> - ✗ FAIL — File should be rejected; target DESC error fired
> - PRE-COND — Pre-condition file to be submitted first (seeds database)
> - DB REQ = Y — Database pre-condition required before running test
> - DB REQ = N — Pure format/content check; no pre-condition needed

## Table of Contents

1. [DESC0004 — Security Threats in Decrypted File](#desc0004)  📋
2. [DESC0008 — DocTypeIndic Test Data in Production Environment](#desc0008)  📋
3. [DESC0009 — ReceivingCountry / TransmittingCountry Must Be HK](#desc0009)  📋
4. [DESC0011 — MessageRefId Format Violation](#desc0011)  📋
5. [DESC0012 — Duplicate MessageRefId](#desc0012)  🗄️
6. [DESC0013 — ReportingPeriod Year Exceeds Current Year](#desc0013)  📋
7. [DESC0015 — CorrDocRefId Points to Wrong Section Type](#desc0015)  🗄️
8. [DESC0017 — Duplicate DocRefId](#desc0017)  🗄️
9. [DESC0018 — CorrDocRefId References Unknown Record](#desc0018)  🗄️
10. [DESC0019 — CorrDocRefId References Outdated Version](#desc0019)  🗄️
11. [DESC0020 — FilingInfo Deletion Without Deleting All Related Sections](#desc0020)  🗄️
12. [DESC0021 — DocRefId Format Violation](#desc0021)  📋
13. [DESC0024 — OECD0 FilingInfo DocRefId Must Match Latest Version](#desc0024)  🗄️

> 🗄️ = DB Required | 📋 = No DB Required


---


## DESC0004 — Security Threats in Decrypted File

<a name="desc0004"></a>

| Item | Detail |
|---|---|
| Rule ID | DESC0004 |
| Error Type | FileError |
| Error Code | 50005 |
| Validation Rule | The decrypted file contains potential security threats (hyperlinks, JavaScript, executable files, unacceptable characters) |
| DB Required | **N** — File content scan only |
| DocTypeIndic Required | Any (file-level check before schema parse) |
| Total Files | 41 (10 Positive + 31 Negative) |


### Positive Test Cases — DESC0004

File should be accepted (no security threats detected)

| Test Case ID | Filename | Test Scenario | Key Test Data | Expected |
|---|---|---|---|---|
| DESC0004_POS_001 | `DESC0004_POS_001_clean_no_threat.xml` | Fully clean file — no URLs, scripts, or executable references | Warning: GIR-CLEAN-COMPLIANT-FY2025 | Contact: QA-TEAM | ✓ PASS |
| DESC0004_POS_002 | `DESC0004_POS_002_plain_text_http_url.xml` | HTTP URL as plain text in Warning field (rule explicitly allows plain text URLs) | Warning: 'http://www.oecd.org/...' as plain text | ✓ PASS |
| DESC0004_POS_003 | `DESC0004_POS_003_plain_text_https_url.xml` | HTTPS URL as plain text in Contact field | Contact: 'https://www.oecd.org/tax/...' as plain text | ✓ PASS |
| DESC0004_POS_004 | `DESC0004_POS_004_plain_text_email.xml` | Email address as plain text data value (not a mailto: hyperlink) | Contact: 'globe-compliance@taxauthority.gov.hk' | ✓ PASS |
| DESC0004_POS_005 | `DESC0004_POS_005_plain_text_ftp_address.xml` | FTP address as plain text (allowed — differs from clickable FTP hyperlink) | Warning: 'ftp://files.taxauthority.gov.hk' as plain text | ✓ PASS |
| DESC0004_POS_006 | `DESC0004_POS_006_plain_text_ip_address.xml` | IP address as plain text string | Contact: '192.168.10.50' as plain text | ✓ PASS |
| DESC0004_POS_007 | `DESC0004_POS_007_plain_text_domain.xml` | Domain name as plain text only (no anchor tag) | Warning: 'taxauthority.gov.hk' plain text domain | ✓ PASS |
| DESC0004_POS_008 | `DESC0004_POS_008_escaped_xml_entities.xml` | Properly escaped XML special chars (&amp; &lt; &gt;) — clean content | Warning: 'Rate &amp; Threshold; Income &lt; 1M' | ✓ PASS |
| DESC0004_POS_009 | `DESC0004_POS_009_utf8_multilingual.xml` | UTF-8 multilingual content (Japanese, German, Korean names) | Contact: '山田太郎 / Müller, José / 김철수' | ✓ PASS |
| DESC0004_POS_010 | `DESC0004_POS_010_additional_info_clean.xml` | AdditionalInfo field with clean explanatory text only | AdditionalInfo: plain narrative text about GIR filing | ✓ PASS |


### Negative Test Cases — DESC0004

File should be rejected (security threat detected)

| Test Case ID | Filename | Category | Threat Injected | Injection Location | Expected |
|---|---|---|---|---|---|
| DESC0004_NEG_001 | `DESC0004_NEG_001_hyperlink_html_anchor_warning.xml` | Hyperlink | HTML `<a href="http://...">` anchor tag | Warning field (CDATA) | ✗ FAIL |
| DESC0004_NEG_002 | `DESC0004_NEG_002_hyperlink_https_anchor_contact.xml` | Hyperlink | HTTPS anchor hyperlink `<a href="https://...">` | Contact field (CDATA) | ✗ FAIL |
| DESC0004_NEG_003 | `DESC0004_NEG_003_hyperlink_mailto.xml` | Hyperlink | Mailto: hyperlink `<a href="mailto:...">` (differs from plain email) | Warning field (CDATA) | ✗ FAIL |
| DESC0004_NEG_004 | `DESC0004_NEG_004_hyperlink_ftp_anchor.xml` | Hyperlink | FTP hyperlink `<a href="ftp://...">` (differs from plain text FTP) | Warning field (CDATA) | ✗ FAIL |
| DESC0004_NEG_005 | `DESC0004_NEG_005_hyperlink_relative_path.xml` | Hyperlink | Relative path hyperlink `<a href="/internal/...">` | Warning field (CDATA) | ✗ FAIL |
| DESC0004_NEG_006 | `DESC0004_NEG_006_hyperlink_additional_info.xml` | Hyperlink | Hyperlink in AdditionalInfo field | AdditionalInfo (CDATA) | ✗ FAIL |
| DESC0004_NEG_007 | `DESC0004_NEG_007_javascript_script_tag.xml` | JavaScript | `<script>alert('XSS')</script>` script tag | Warning field (CDATA) | ✗ FAIL |
| DESC0004_NEG_008 | `DESC0004_NEG_008_javascript_protocol_url.xml` | JavaScript | `javascript:alert(...)` protocol URL | Warning field (plain text) | ✗ FAIL |
| DESC0004_NEG_009 | `DESC0004_NEG_009_javascript_onclick_handler.xml` | JavaScript | `onclick="exfiltrateData()"` event handler | Warning field (CDATA) | ✗ FAIL |
| DESC0004_NEG_010 | `DESC0004_NEG_010_javascript_onload_handler.xml` | JavaScript | `onload="sendCookiesToAttacker()"` handler | Warning field (CDATA) | ✗ FAIL |
| DESC0004_NEG_011 | `DESC0004_NEG_011_javascript_eval_obfuscated.xml` | JavaScript | Obfuscated JS via `eval(atob('...'))` | Warning field | ✗ FAIL |
| DESC0004_NEG_012 | `DESC0004_NEG_012_javascript_base64_data_uri.xml` | JavaScript | Base64-encoded JavaScript data URI | Warning field | ✗ FAIL |
| DESC0004_NEG_013 | `DESC0004_NEG_013_vbscript_tag.xml` | JavaScript | `<script language="VBScript">` tag | Warning field (CDATA) | ✗ FAIL |
| DESC0004_NEG_014 | `DESC0004_NEG_014_javascript_href_anchor.xml` | JavaScript | Anchor with `href="javascript:document.cookie"` | Warning field (CDATA) | ✗ FAIL |
| DESC0004_NEG_015 | `DESC0004_NEG_015_executable_exe.xml` | Executable | Reference to `.exe` file: `GlobeClient_Setup.exe` | Warning field | ✗ FAIL |
| DESC0004_NEG_016 | `DESC0004_NEG_016_executable_bat.xml` | Executable | Reference to `.bat` batch file | Contact field | ✗ FAIL |
| DESC0004_NEG_017 | `DESC0004_NEG_017_executable_ps1.xml` | Executable | Reference to `.ps1` PowerShell script | Warning field | ✗ FAIL |
| DESC0004_NEG_018 | `DESC0004_NEG_018_executable_vbs.xml` | Executable | Reference to `.vbs` VBScript file | Warning field | ✗ FAIL |
| DESC0004_NEG_019 | `DESC0004_NEG_019_executable_dll.xml` | Executable | Reference to `.dll` dynamic library | Warning field | ✗ FAIL |
| DESC0004_NEG_020 | `DESC0004_NEG_020_executable_sh.xml` | Executable | Reference to `.sh` shell script | Contact field | ✗ FAIL |
| DESC0004_NEG_021 | `DESC0004_NEG_021_executable_cmd.xml` | Executable | Reference to `.cmd` command file | Warning field | ✗ FAIL |
| DESC0004_NEG_022 | `DESC0004_NEG_022_executable_msi.xml` | Executable | Reference to `.msi` Windows installer | Warning field | ✗ FAIL |
| DESC0004_NEG_023 | `DESC0004_NEG_023_xxe_local_file.xml` | XML Attack | XXE injection: `<!ENTITY xxe SYSTEM "file:///etc/passwd">` | DOCTYPE declaration | ✗ FAIL |
| DESC0004_NEG_024 | `DESC0004_NEG_024_xxe_ssrf_network.xml` | XML Attack | XXE SSRF: `<!ENTITY ssrf SYSTEM "http://internal.server.local">` | DOCTYPE declaration | ✗ FAIL |
| DESC0004_NEG_025 | `DESC0004_NEG_025_doctype_system.xml` | XML Attack | DOCTYPE SYSTEM: `<!DOCTYPE GLOBE_OECD SYSTEM "http://attacker.com/malicious.dtd">` | DOCTYPE declaration | ✗ FAIL |
| DESC0004_NEG_026 | `DESC0004_NEG_026_xss_cdata_payload.xml` | XML Attack | XSS: `<img src=x onerror=alert("XSS")>` in CDATA | Warning field (CDATA) | ✗ FAIL |
| DESC0004_NEG_027 | `DESC0004_NEG_027_sql_injection.xml` | XML Attack | SQL injection: `'; DROP TABLE GlobeReports;--` | Warning field | ✗ FAIL |
| DESC0004_NEG_028 | `DESC0004_NEG_028_iframe_tag.xml` | Other | Hidden `<iframe src="http://malicious.com">` tag | Warning field (CDATA) | ✗ FAIL |
| DESC0004_NEG_029 | `DESC0004_NEG_029_activex_object.xml` | Other | ActiveX `<object classid="clsid:...">` reference | Warning field (CDATA) | ✗ FAIL |
| DESC0004_NEG_030 | `DESC0004_NEG_030_control_characters.xml` | Other | Unacceptable control chars `\x01\x07\x0B` embedded | Warning field | ✗ FAIL |
| DESC0004_NEG_031 | `DESC0004_NEG_031_null_byte_injection.xml` | Other | Null byte `\x00` injected (binary file write) | Warning field (binary) | ✗ FAIL |

---


## DESC0008 — DocTypeIndic Test Data in Production Environment

<a name="desc0008"></a>

| Item | Detail |
|---|---|
| Rule ID | DESC0008 |
| Error Type | FileError |
| Error Code | 50009 |
| Validation Rule | Production environment cannot accept files with DocTypeIndic OECD10–OECD13 (test data range) |
| DB Required | **N** |
| Affected Sections | FilingInfo, GeneralSection, Summary (×2), JurisdictionSection (×2), UTPRAttribution |
| Total Files | 25 (10 Positive + 15 Negative) |

> **DocTypeIndic ranges**: OECD0–3 = Production (valid) | OECD10–13 = Test data (triggers DESC0008)
> 
> **Section positions in baseline**: #1=FilingInfo | #2=GeneralSection | #3=Summary-JP | #4=Summary-HK | #5=JurisdictionSection-JP | #6=JurisdictionSection-HK | #7=UTPRAttribution


### Positive Test Cases — DESC0008

All 7 DocTypeIndic values in OECD0–3 range

| Test Case ID | Filename | FI | GS | S-JP | S-HK | JS-JP | JS-HK | UTPR | Expected |
|---|---|---|---|---|---|---|---|---|---|
| DESC0008_POS001 | `DESC0008_POS001_all_OECD1_new_data` | OECD1 | OECD1 | OECD1 | OECD1 | OECD1 | OECD1 | OECD1 | ✓ PASS |
| DESC0008_POS002 | `DESC0008_POS002_all_OECD0_resent` | OECD0 | OECD0 | OECD0 | OECD0 | OECD0 | OECD0 | OECD0 | ✓ PASS |
| DESC0008_POS003 | `DESC0008_POS003_all_OECD2_corrected` | OECD2 | OECD2 | OECD2 | OECD2 | OECD2 | OECD2 | OECD2 | ✓ PASS |
| DESC0008_POS004 | `DESC0008_POS004_all_OECD3_deletion` | OECD3 | OECD3 | OECD3 | OECD3 | OECD3 | OECD3 | OECD3 | ✓ PASS |
| DESC0008_POS005 | `DESC0008_POS005_summary_corrected_rest_new` | OECD1 | OECD1 | OECD2 | OECD2 | OECD1 | OECD1 | OECD1 | ✓ PASS |
| DESC0008_POS006 | `DESC0008_POS006_filinginfo_resent_rest_new` | OECD0 | OECD1 | OECD1 | OECD1 | OECD1 | OECD1 | OECD1 | ✓ PASS |
| DESC0008_POS007 | `DESC0008_POS007_jursections_corrected_rest_new` | OECD1 | OECD1 | OECD1 | OECD1 | OECD2 | OECD2 | OECD1 | ✓ PASS |
| DESC0008_POS008 | `DESC0008_POS008_utpr_corrected_rest_new` | OECD1 | OECD1 | OECD1 | OECD1 | OECD1 | OECD1 | OECD2 | ✓ PASS |
| DESC0008_POS009 | `DESC0008_POS009_filing_general_utpr_corrected_rest_new` | OECD2 | OECD2 | OECD1 | OECD1 | OECD1 | OECD1 | OECD2 | ✓ PASS |
| DESC0008_POS010 | `DESC0008_POS010_all_four_production_values_mixed` | OECD1 | OECD0 | OECD2 | OECD3 | OECD0 | OECD1 | OECD2 | ✓ PASS |


### Negative Test Cases — DESC0008

At least one DocTypeIndic in OECD10–13 range

| Test Case ID | Filename | FI | GS | S-JP | S-HK | JS-JP | JS-HK | UTPR | Violations | Expected |
|---|---|---|---|---|---|---|---|---|---|---|
| DESC0008_NEG001 | `DESC0008_NEG001_only_filinginfo_OECD11` | **OECD11** | OECD1 | OECD1 | OECD1 | OECD1 | OECD1 | OECD1 | 1 — FilingInfo only | ✗ FAIL |
| DESC0008_NEG002 | `DESC0008_NEG002_only_generalsection_OECD11` | OECD1 | **OECD11** | OECD1 | OECD1 | OECD1 | OECD1 | OECD1 | 1 — GeneralSection only | ✗ FAIL |
| DESC0008_NEG003 | `DESC0008_NEG003_only_summaries_OECD11` | OECD1 | OECD1 | **OECD11** | **OECD11** | OECD1 | OECD1 | OECD1 | 2 — Both Summaries | ✗ FAIL |
| DESC0008_NEG004 | `DESC0008_NEG004_only_jursections_OECD11` | OECD1 | OECD1 | OECD1 | OECD1 | **OECD11** | **OECD11** | OECD1 | 2 — Both JurSections | ✗ FAIL |
| DESC0008_NEG005 | `DESC0008_NEG005_only_utpr_OECD11` | OECD1 | OECD1 | OECD1 | OECD1 | OECD1 | OECD1 | **OECD11** | 1 — UTPR only | ✗ FAIL |
| DESC0008_NEG006 | `DESC0008_NEG006_all_OECD11_test_new` | **OECD11** | **OECD11** | **OECD11** | **OECD11** | **OECD11** | **OECD11** | **OECD11** | 7 — All (same as baseline) | ✗ FAIL |
| DESC0008_NEG007 | `DESC0008_NEG007_all_OECD10_test_resent` | **OECD10** | **OECD10** | **OECD10** | **OECD10** | **OECD10** | **OECD10** | **OECD10** | 7 — All OECD10 | ✗ FAIL |
| DESC0008_NEG008 | `DESC0008_NEG008_all_OECD12_test_corrected` | **OECD12** | **OECD12** | **OECD12** | **OECD12** | **OECD12** | **OECD12** | **OECD12** | 7 — All OECD12 | ✗ FAIL |
| DESC0008_NEG009 | `DESC0008_NEG009_all_OECD13_test_deletion` | **OECD13** | **OECD13** | **OECD13** | **OECD13** | **OECD13** | **OECD13** | **OECD13** | 7 — All OECD13 | ✗ FAIL |
| DESC0008_NEG010 | `DESC0008_NEG010_filing_general_test_rest_production` | **OECD11** | **OECD11** | OECD1 | OECD1 | OECD1 | OECD1 | OECD1 | 2 — FI+GS | ✗ FAIL |
| DESC0008_NEG011 | `DESC0008_NEG011_summary_jursection_test_rest_production` | OECD1 | OECD1 | **OECD11** | **OECD11** | **OECD12** | **OECD12** | OECD1 | 4 — Summary+JurSect | ✗ FAIL |
| DESC0008_NEG012 | `DESC0008_NEG012_all_mixed_test_values_10to13` | **OECD10** | **OECD11** | **OECD12** | **OECD13** | **OECD10** | **OECD11** | **OECD12** | 7 — Mixed 10-13 | ✗ FAIL |
| DESC0008_NEG013 | `DESC0008_NEG013_only_jursections_OECD10_test_resent` | OECD1 | OECD1 | OECD1 | OECD1 | **OECD10** | **OECD10** | OECD1 | 2 — JurSects OECD10 | ✗ FAIL |
| DESC0008_NEG014 | `DESC0008_NEG014_only_filinginfo_OECD12_test_corrected` | **OECD12** | OECD1 | OECD1 | OECD1 | OECD1 | OECD1 | OECD1 | 1 — FI OECD12 | ✗ FAIL |
| DESC0008_NEG015 | `DESC0008_NEG015_only_one_summary_OECD13_test_deletion` | OECD1 | OECD1 | **OECD13** | OECD1 | OECD1 | OECD1 | OECD1 | 1 — Summary-JP OECD13 | ✗ FAIL |

---


## DESC0009 — ReceivingCountry / TransmittingCountry Must Be HK

<a name="desc0009"></a>

| Item | Detail |
|---|---|
| Rule ID | DESC0009 |
| Error Type | FileError |
| Error Code | 50010 |
| Validation Rule | `MessageSpec/TransmittingCountry` and `MessageSpec/ReceivingCountry` must both equal **'HK'** |
| DB Required | **N** |
| Total Files | 20 (5 Positive + 15 Negative) |


### Positive Test Cases — DESC0009


| Test Case ID | Filename | TransmittingCountry | ReceivingCountry | MessageTypeIndic | DocTypeIndic | Expected |
|---|---|---|---|---|---|---|
| DESC0009_POS001 | `DESC0009_POS001_both_HK_GIR101_new_data` | HK | HK | GIR101 | OECD1 | ✓ PASS |
| DESC0009_POS002 | `DESC0009_POS002_both_HK_GIR102_corrections` | HK | HK | GIR102 | OECD1 | ✓ PASS |
| DESC0009_POS003 | `DESC0009_POS003_both_HK_GIR103_no_data` | HK | HK | GIR103 | OECD1 | ✓ PASS |
| DESC0009_POS004 | `DESC0009_POS004_both_HK_OECD2_corrected` | HK | HK | GIR101 | OECD2 | ✓ PASS |
| DESC0009_POS005 | `DESC0009_POS005_both_HK_OECD3_deletion` | HK | HK | GIR101 | OECD3 | ✓ PASS |


### Negative Test Cases — DESC0009


| Test Case ID | Filename | TX Country | RC Country | TX Valid? | RC Valid? | Group | Expected |
|---|---|---|---|---|---|---|---|
| DESC0009_NEG001 | `DESC0009_NEG001_RC_JP_TX_HK` | HK | JP | ✓ | ✗ | RC wrong only | ✗ FAIL |
| DESC0009_NEG002 | `DESC0009_NEG002_RC_US_TX_HK` | HK | US | ✓ | ✗ | RC wrong only | ✗ FAIL |
| DESC0009_NEG003 | `DESC0009_NEG003_RC_GB_TX_HK` | HK | GB | ✓ | ✗ | RC wrong only | ✗ FAIL |
| DESC0009_NEG004 | `DESC0009_NEG004_RC_SG_TX_HK` | HK | SG | ✓ | ✗ | RC wrong only | ✗ FAIL |
| DESC0009_NEG005 | `DESC0009_NEG005_RC_CN_TX_HK` | HK | CN | ✓ | ✗ | RC wrong only | ✗ FAIL |
| DESC0009_NEG006 | `DESC0009_NEG006_TX_JP_RC_HK` | JP | HK | ✗ | ✓ | TX wrong only | ✗ FAIL |
| DESC0009_NEG007 | `DESC0009_NEG007_TX_US_RC_HK` | US | HK | ✗ | ✓ | TX wrong only | ✗ FAIL |
| DESC0009_NEG008 | `DESC0009_NEG008_TX_GB_RC_HK` | GB | HK | ✗ | ✓ | TX wrong only | ✗ FAIL |
| DESC0009_NEG009 | `DESC0009_NEG009_TX_SG_RC_HK` | SG | HK | ✗ | ✓ | TX wrong only | ✗ FAIL |
| DESC0009_NEG010 | `DESC0009_NEG010_TX_CN_RC_HK` | CN | HK | ✗ | ✓ | TX wrong only | ✗ FAIL |
| DESC0009_NEG011 | `DESC0009_NEG011_TX_JP_RC_JP_same_wrong` | JP | JP | ✗ | ✗ | Both wrong (same) | ✗ FAIL |
| DESC0009_NEG012 | `DESC0009_NEG012_TX_US_RC_JP_diff_wrong` | US | JP | ✗ | ✗ | Both wrong (diff) | ✗ FAIL |
| DESC0009_NEG013 | `DESC0009_NEG013_TX_JP_RC_US_diff_wrong` | JP | US | ✗ | ✗ | Both wrong (diff) | ✗ FAIL |
| DESC0009_NEG014 | `DESC0009_NEG014_TX_SG_RC_CN_diff_wrong` | SG | CN | ✗ | ✗ | Both wrong (diff) | ✗ FAIL |
| DESC0009_NEG015 | `DESC0009_NEG015_TX_CN_RC_US_diff_wrong` | CN | US | ✗ | ✗ | Both wrong (diff) | ✗ FAIL |

---


## DESC0011 — MessageRefId Format Violation

<a name="desc0011"></a>

| Item | Detail |
|---|---|
| Rule ID | DESC0011 |
| Error Type | SevereError |
| Error Code | 60001 |
| Validation Rule | `MessageSpec/MessageRefId` must follow format: `{CC(2)}{Year(4)}{CC(2)}{UID(1+)}` |
| DB Required | **N** — Format check only |
| DocTypeIndic Required | OECD1 (Test File Type = N/A → not checked for OECD10-13) |
| Format Example | `HK2025HKTC-70005-001` (SendCC + Year + RcvCC + UniqueID) |
| Total Files | 20 (5 Positive + 15 Negative) |

> **Positional format**: pos[1-2]=SendingCC | pos[3-6]=Year | pos[7-8]=ReceivingCC | pos[9+]=UniqueID


### Positive Test Cases — DESC0011


| Test Case ID | Filename | MessageRefId | pos[1-2] | pos[3-6] | pos[7-8] | pos[9+] | Expected |
|---|---|---|---|---|---|---|---|
| DESC0011_POS001 | `DESC0011_POS001_standard_baseline` | `HK2025HKTC-70005-001` | ✓ HK | ✓ 2025 | ✓ HK | ✓ TC-70005-001 | ✓ PASS |
| DESC0011_POS002 | `DESC0011_POS002_minimal_uid_3chars` | `HK2025HK001` | ✓ HK | ✓ 2025 | ✓ HK | ✓ 001 | ✓ PASS |
| DESC0011_POS003 | `DESC0011_POS003_single_char_uid_boundary` | `HK2025HKA` | ✓ HK | ✓ 2025 | ✓ HK | ✓ A (min) | ✓ PASS |
| DESC0011_POS004 | `DESC0011_POS004_long_descriptive_uid_with_dashes` | `HK2025HKGIR-PROD-2025-FILING-0001` | ✓ HK | ✓ 2025 | ✓ HK | ✓ GIR-PROD-... | ✓ PASS |
| DESC0011_POS005 | `DESC0011_POS005_numeric_and_alpha_uid` | `HK2025HK20251231FILING001` | ✓ HK | ✓ 2025 | ✓ HK | ✓ 20251231... | ✓ PASS |


### Negative Test Cases — DESC0011


| Test Case ID | Filename | MessageRefId | Violation | pos[1-2] | pos[3-6] | pos[7-8] | Expected |
|---|---|---|---|---|---|---|---|
| DESC0011_NEG001 | `DESC0011_NEG001_sending_cc_1char` | `H2025HK001` | Sending CC contains digit | ✗ H2 | ✗ 025H | ✗ K0 | ✗ FAIL |
| DESC0011_NEG002 | `DESC0011_NEG002_sending_cc_lowercase` | `hk2025HK001` | Sending CC lowercase | ✗ hk | ✓ 2025 | ✓ HK | ✗ FAIL |
| DESC0011_NEG003 | `DESC0011_NEG003_sending_cc_starts_with_digit` | `1K2025HK001` | Digit at pos 1 of CC | ✗ 1K | ✓ 2025 | ✓ HK | ✗ FAIL |
| DESC0011_NEG004 | `DESC0011_NEG004_sending_cc_3chars_shifts_year` | `HKK2025HK001` | 3-char CC shifts year to K202 | ✓ HK | ✗ K202 | ✗ 5H | ✗ FAIL |
| DESC0011_NEG005 | `DESC0011_NEG005_year_2digits` | `HK25HK001` | 2-digit year → pos[3-6]=25HK | ✓ HK | ✗ 25HK | ✗ 00 | ✗ FAIL |
| DESC0011_NEG006 | `DESC0011_NEG006_year_3digits` | `HK202HK001` | 3-digit year → pos[3-6]=202H | ✓ HK | ✗ 202H | ✗ K0 | ✗ FAIL |
| DESC0011_NEG007 | `DESC0011_NEG007_year_all_letters` | `HKabcdHK001` | Year all letters (abcd) | ✓ HK | ✗ abcd | ✓ HK | ✗ FAIL |
| DESC0011_NEG008 | `DESC0011_NEG008_year_mismatch_reportingperiod` | `HK2024HK001` | Year 2024 ≠ ReportingPeriod 2025 | ✓ HK | ✗ 2024 | ✓ HK | ✗ FAIL |
| DESC0011_NEG009 | `DESC0011_NEG009_year_missing_cc_adjacent` | `HKHK001` | Year absent → pos[3-6]=HK00 | ✓ HK | ✗ HK00 | ✗ 1 | ✗ FAIL |
| DESC0011_NEG010 | `DESC0011_NEG010_receiving_cc_lowercase` | `HK2025hk001` | Receiving CC lowercase | ✓ HK | ✓ 2025 | ✗ hk | ✗ FAIL |
| DESC0011_NEG011 | `DESC0011_NEG011_receiving_cc_digit_in_pos7` | `HK20251K001` | Digit in receiving CC pos7 | ✓ HK | ✓ 2025 | ✗ 1K | ✗ FAIL |
| DESC0011_NEG012 | `DESC0011_NEG012_receiving_cc_both_digits` | `HK202512001` | Both receiving CC positions are digits | ✓ HK | ✓ 2025 | ✗ 12 | ✗ FAIL |
| DESC0011_NEG013 | `DESC0011_NEG013_uniqueid_completely_missing` | `HK2025HK` | UID absent (8 chars exactly) | ✓ HK | ✓ 2025 | ✓ HK | ✗ FAIL |
| DESC0011_NEG014 | `DESC0011_NEG014_receiving_cc_and_uid_missing` | `HK2025` | Receiving CC + UID both missing (6 chars) | ✓ HK | ✓ 2025 | ✗ (missing) | ✗ FAIL |
| DESC0011_NEG015 | `DESC0011_NEG015_completely_wrong_format` | `TOTALLY-INVALID-FORMAT-123` | Completely malformed → pos[3-6]=TALL | ✓ TO | ✗ TALL | ✗ Y- | ✗ FAIL |

---


## DESC0012 — Duplicate MessageRefId

<a name="desc0012"></a>

| Item | Detail |
|---|---|
| Rule ID | DESC0012 |
| Error Type | SevereError |
| Error Code | 60002 |
| Validation Rule | `MessageSpec/MessageRefId` must be unique globally (never used before) |
| DB Required | **Y** — System checks against all previously received MessageRefIds |
| DocTypeIndic Required | OECD1 (Test File Type = N/A) |
| Total Files | 15 (5 Positive + 5 NEG-STEP1 pre-conditions + 5 NEG-STEP2 tests) |

> **Test Execution Order**: For each NEG scenario — submit STEP1 first (seeds DB), then STEP2 (triggers DESC0012)


### Positive Test Cases — DESC0012


| Test Case ID | Filename | MessageRefId | DocTypeIndic | Notes | Expected |
|---|---|---|---|---|---|
| DESC0012_POS001 | `DESC0012_POS001_unique_id_GIR101_OECD1` | `HK2025HKTC-DESC0012-UNIQUE001` | OECD1 | Brand-new unique ID — standard new data | ✓ PASS |
| DESC0012_POS002 | `DESC0012_POS002_unique_id_GIR102_correction` | `HK2025HKTC-DESC0012-UNIQUE002` | OECD2 | Unique ID for correction (GIR102) — new ID required per User Guide | ✓ PASS |
| DESC0012_POS003 | `DESC0012_POS003_unique_id_GIR103_no_data` | `HK2025HKTC-DESC0012-UNIQUE003` | OECD1 | Unique ID for no-data report (GIR103) | ✓ PASS |
| DESC0012_POS004 | `DESC0012_POS004_unique_id_timestamp_suffix` | `HK2025HKTC-DESC0012-UNIQUE004` | OECD1 | Timestamp-embedded unique ID pattern | ✓ PASS |
| DESC0012_POS005 | `DESC0012_POS005_unique_id_OECD3_deletion` | `HK2025HKTC-DESC0012-UNIQUE005` | OECD3 | Unique ID for deletion — new ID required even for deletions | ✓ PASS |


### Negative Test Cases — DESC0012 (2-Step Process)


| Test Case ID | Filename | Step | Shared MessageRefId | Scenario | Expected |
|---|---|---|---|---|---|
| DESC0012_NEG001_STEP1 | `DESC0012_NEG001_STEP1_initial_new_submission` | PRE-COND | `HK2025HKTC-DESC0012-DUP001` | Initial new submission — seeds DB | ✓ PASS (pre-cond) |
| DESC0012_NEG001_STEP2 | `DESC0012_NEG001_STEP2_exact_duplicate_same_content` | TEST | `HK2025HKTC-DESC0012-DUP001` | Exact duplicate — same content + same ID | ✗ FAIL |
| DESC0012_NEG002_STEP1 | `DESC0012_NEG002_STEP1_initial_submission_content_A` | PRE-COND | `HK2025HKTC-DESC0012-DUP002` | Initial submission with content A | ✓ PASS (pre-cond) |
| DESC0012_NEG002_STEP2 | `DESC0012_NEG002_STEP2_resubmit_diff_warning_same_id` | TEST | `HK2025HKTC-DESC0012-DUP002` | Same ID, different Warning text — DB checks ID not content | ✗ FAIL |
| DESC0012_NEG003_STEP1 | `DESC0012_NEG003_STEP1_initial_GIR101` | PRE-COND | `HK2025HKTC-DESC0012-DUP003` | Initial GIR101 new data submission | ✓ PASS (pre-cond) |
| DESC0012_NEG003_STEP2 | `DESC0012_NEG003_STEP2_resubmit_GIR102_same_id` | TEST | `HK2025HKTC-DESC0012-DUP003` | GIR102 correction attempt with same ID — correction must use new ID | ✗ FAIL |
| DESC0012_NEG004_STEP1 | `DESC0012_NEG004_STEP1_initial_OECD1_new` | PRE-COND | `HK2025HKTC-DESC0012-DUP004` | Initial OECD1 production filing | ✓ PASS (pre-cond) |
| DESC0012_NEG004_STEP2 | `DESC0012_NEG004_STEP2_resubmit_OECD2_corrected_same_id` | TEST | `HK2025HKTC-DESC0012-DUP004` | OECD2 resubmit with same ID — DocTypeIndic change doesn't allow ID reuse | ✗ FAIL |
| DESC0012_NEG005_STEP1 | `DESC0012_NEG005_STEP1_initial_submission_seeds_db` | PRE-COND | `HK2025HKTC-DESC0012-DUP005` | Initial submission seeds DB | ✓ PASS (pre-cond) |
| DESC0012_NEG005_STEP2 | `DESC0012_NEG005_STEP2_second_attempt_first_duplicate` | TEST | `HK2025HKTC-DESC0012-DUP005` | 2nd attempt with same ID — verifies ID persists in DB after STEP1 | ✗ FAIL |

---


## DESC0013 — ReportingPeriod Year Exceeds Current Year

<a name="desc0013"></a>

| Item | Detail |
|---|---|
| Rule ID | DESC0013 |
| Error Type | SevereError |
| Error Code | 60003 |
| Validation Rule | `MessageSpec/ReportingPeriod` YYYY must be ≤ current year |
| Current Year | **2026** (as of 2026-06-10) |
| DB Required | **N** — Date comparison only |
| DocTypeIndic Required | OECD1 (Test File Type = N/A) |
| Total Files | 15 (5 Positive + 10 Negative) |

> **Note**: Rule checks only the YYYY portion — not month/day. Updated dates: ReportingPeriod, FilingInfo/Period/Start, Period/End, ChangeDate, ElectionYear, MessageRefId year


### Positive Test Cases — DESC0013


| Test Case ID | Filename | ReportingPeriod | YYYY | Delta from 2026 | Expected |
|---|---|---|---|---|---|
| DESC0013_POS001 | `DESC0013_POS001_year_2025_prior_standard` | `2025-12-31` | 2025 | -1 year | ✓ PASS |
| DESC0013_POS002 | `DESC0013_POS002_year_2024_two_years_prior` | `2024-12-31` | 2024 | -2 years | ✓ PASS |
| DESC0013_POS003 | `DESC0013_POS003_year_2023_three_years_prior` | `2023-12-31` | 2023 | -3 years | ✓ PASS |
| DESC0013_POS004 | `DESC0013_POS004_year_2026_current_year_end` | `2026-12-31` | 2026 | 0 (boundary max) | ✓ PASS |
| DESC0013_POS005 | `DESC0013_POS005_year_2026_current_year_start` | `2026-01-01` | 2026 | 0 (year-start edge) | ✓ PASS |


### Negative Test Cases — DESC0013


| Test Case ID | Filename | ReportingPeriod | YYYY | Delta from 2026 | Date Pattern | Expected |
|---|---|---|---|---|---|---|
| DESC0013_NEG001 | `DESC0013_NEG001_year_2027_yearend_boundary_plus1` | `2027-12-31` | 2027 | +1 year | Year-end | ✗ FAIL |
| DESC0013_NEG002 | `DESC0013_NEG002_year_2027_yearstart` | `2027-01-01` | 2027 | +1 year | Year-start | ✗ FAIL |
| DESC0013_NEG003 | `DESC0013_NEG003_year_2027_midyear` | `2027-06-30` | 2027 | +1 year | Mid-year | ✗ FAIL |
| DESC0013_NEG004 | `DESC0013_NEG004_year_2028_yearend` | `2028-12-31` | 2028 | +2 years | Year-end | ✗ FAIL |
| DESC0013_NEG005 | `DESC0013_NEG005_year_2028_q1_end` | `2028-03-31` | 2028 | +2 years | Q1 end | ✗ FAIL |
| DESC0013_NEG006 | `DESC0013_NEG006_year_2029_yearend` | `2029-12-31` | 2029 | +3 years | Year-end | ✗ FAIL |
| DESC0013_NEG007 | `DESC0013_NEG007_year_2030_yearend` | `2030-12-31` | 2030 | +4 years | Year-end | ✗ FAIL |
| DESC0013_NEG008 | `DESC0013_NEG008_year_2035_yearend` | `2035-12-31` | 2035 | +9 years | Far future | ✗ FAIL |
| DESC0013_NEG009 | `DESC0013_NEG009_year_2050_yearend` | `2050-12-31` | 2050 | +24 years | Far future | ✗ FAIL |
| DESC0013_NEG010 | `DESC0013_NEG010_year_2099_extreme_future` | `2099-12-31` | 2099 | +73 years | Extreme future | ✗ FAIL |

---


## DESC0015 — CorrDocRefId Points to Wrong Section Type

<a name="desc0015"></a>

| Item | Detail |
|---|---|
| Rule ID | DESC0015 |
| Error Type | SevereError |
| Error Code | 60005 |
| Validation Rule | When DocTypeIndic is OECD2/3, CorrDocRefId must point to a record **of the same section type** |
| DB Required | **Y** — DB must contain original DocRefIds for CorrDocRefId to reference |
| Section Types | FilingInfo | GeneralSection | Summary | JurisdictionSection | UTPRAttribution |
| Total Files | 16 (1 STEP1 + 5 Positive + 10 Negative) |

> **Pre-condition**: `DESC0015_D01_STEP1_initial_all_oecd1.xml` must be submitted first
> 
> **Original DocRefIds** (created in STEP1):
> - FilingInfo: `HK2025FilingInfoTC-DESC0015-D01`
> - GeneralSection: `HK2025GeneralSectionTC-DESC0015-D01`
> - Summary-JP: `HK2025Summary1TC-DESC0015-D01`
> - Summary-HK: `HK2025Summary2TC-DESC0015-D01`
> - JurisdictionSection-JP: `HK2025JurisdictionSection1TC-DESC0015-D01`
> - JurisdictionSection-HK: `HK2025JurisdictionSection2TC-DESC0015-D01`
> - UTPRAttribution: `HK2025UTPRAttributionTC-DESC0015-D01`


#### Pre-condition File


| Test Case ID | Filename | Action | Expected |
|---|---|---|---|
| DESC0015_D01_STEP1 | `DESC0015_D01_STEP1_initial_all_oecd1.xml` | Submit first — all OECD1, creates D01 DocRefIds in DB | ✓ PASS (pre-cond) |


### Positive Test Cases — DESC0015


| Test Case ID | Filename | Correcting Section | DocType | CorrDocRefId Points To | Section Type Match | Expected |
|---|---|---|---|---|---|---|
| DESC0015_POS001 | `DESC0015_POS001_STEP2_filinginfo_oecd2_correct_corrref` | FilingInfo | OECD2 | D01_FilingInfo | FilingInfo → FilingInfo ✓ | ✓ PASS |
| DESC0015_POS002 | `DESC0015_POS002_STEP2_generalsection_oecd2_correct_corrref` | GeneralSection | OECD2 | D01_GeneralSection | GeneralSection → GeneralSection ✓ | ✓ PASS |
| DESC0015_POS003 | `DESC0015_POS003_STEP2_summary-jp_oecd3_correct_corrref` | Summary-JP | OECD3 | D01_Summary-JP | Summary → Summary ✓ | ✓ PASS |
| DESC0015_POS004 | `DESC0015_POS004_STEP2_jurisdictionsection-jp_oecd2_correct_corrref` | JurisdictionSection-JP | OECD2 | D01_JurSect-JP | JurisdictionSection → JurisdictionSection ✓ | ✓ PASS |
| DESC0015_POS005 | `DESC0015_POS005_STEP2_utprattribution_oecd3_correct_corrref` | UTPRAttribution | OECD3 | D01_UTPRAttribution | UTPRAttribution → UTPRAttribution ✓ | ✓ PASS |


### Negative Test Cases — DESC0015


| Test Case ID | Filename | Correcting Section | DocType | CorrDocRefId Points To | Violation | Expected |
|---|---|---|---|---|---|---|
| DESC0015_NEG001 | `DESC0015_NEG001_STEP2_filinginfo_oecd2_points_to_generalsection` | FilingInfo | OECD2 | D01_GeneralSection | FI → GS (FI ≠ GeneralSection) | ✗ FAIL |
| DESC0015_NEG002 | `DESC0015_NEG002_STEP2_filinginfo_oecd3_points_to_summaryjp` | FilingInfo | OECD3 | D01_Summary-JP | FI → Summary (FI ≠ Summary) | ✗ FAIL |
| DESC0015_NEG003 | `DESC0015_NEG003_STEP2_generalsection_oecd2_points_to_filinginfo` | GeneralSection | OECD2 | D01_FilingInfo | GS → FI (GS ≠ FilingInfo) | ✗ FAIL |
| DESC0015_NEG004 | `DESC0015_NEG004_STEP2_generalsection_oecd3_points_to_jurisdictionsectionjp` | GeneralSection | OECD3 | D01_JurSect-JP | GS → JS (GS ≠ JurisdictionSection) | ✗ FAIL |
| DESC0015_NEG005 | `DESC0015_NEG005_STEP2_summary-jp_oecd2_points_to_filinginfo` | Summary-JP | OECD2 | D01_FilingInfo | Summary → FI (Summary ≠ FilingInfo) | ✗ FAIL |
| DESC0015_NEG006 | `DESC0015_NEG006_STEP2_summary-jp_oecd3_points_to_utprattribution` | Summary-JP | OECD3 | D01_UTPRAttribution | Summary → UTPR (Summary ≠ UTPRAttribution) | ✗ FAIL |
| DESC0015_NEG007 | `DESC0015_NEG007_STEP2_jurisdictionsection-jp_oecd2_points_to_summaryjp` | JurisdictionSection-JP | OECD2 | D01_Summary-JP | JS → Summary (JS ≠ Summary) | ✗ FAIL |
| DESC0015_NEG008 | `DESC0015_NEG008_STEP2_jurisdictionsection-jp_oecd3_points_to_generalsection` | JurisdictionSection-JP | OECD3 | D01_GeneralSection | JS → GS (JS ≠ GeneralSection) | ✗ FAIL |
| DESC0015_NEG009 | `DESC0015_NEG009_STEP2_utprattribution_oecd2_points_to_jurisdictionsectionjp` | UTPRAttribution | OECD2 | D01_JurSect-JP | UTPR → JS (UTPR ≠ JurisdictionSection) | ✗ FAIL |
| DESC0015_NEG010 | `DESC0015_NEG010_STEP2_utprattribution_oecd3_points_to_summaryhk` | UTPRAttribution | OECD3 | D01_Summary-HK | UTPR → Summary (UTPR ≠ Summary) | ✗ FAIL |

---


## DESC0017 — Duplicate DocRefId

<a name="desc0017"></a>

| Item | Detail |
|---|---|
| Rule ID | DESC0017 |
| Error Type | SevereError |
| Error Code | 60007 |
| Validation Rule | Each DocRefId in the file must be unique globally (not already in DB) |
| DB Required | **Y** — DB contains all previously submitted DocRefIds |
| Granularity | Per section — each of the 7 DocRefIds checked independently |
| Total Files | 16 (1 STEP1 + 5 Positive + 10 Negative) |

> **Pre-condition**: `DESC0017_D01_STEP1_initial_all_oecd1.xml` seeds DB with D01 DocRefIds
> OECD2/3 corrections must ALWAYS use NEW unique DocRefIds (not reuse the old ones)


#### Pre-condition File


| Test Case ID | Filename | DocRefId Pattern | Expected |
|---|---|---|---|
| DESC0017_D01_STEP1 | `DESC0017_D01_STEP1_initial_all_oecd1.xml` | `HK2025{Section}TC-DESC0017-D01` (7 sections) | ✓ PASS (pre-cond) |


### Positive Test Cases — DESC0017


| Test Case ID | Filename | DocTypeIndic | DocRefId Pattern | Notes | Expected |
|---|---|---|---|---|---|
| DESC0017_POS001 | `DESC0017_POS001_all_oecd1_new_unique` | OECD1 | HK2025{Section}TC-DESC0017-POS001 | All 7 brand-new unique DocRefIds | ✓ PASS |
| DESC0017_POS002 | `DESC0017_POS002_all_oecd2_correction_new_ids` | OECD2 | HK2025{Section}TC-DESC0017-POS002 + CorrDocRefId=D01 | Correction — new DocRefIds + correct CorrDocRefIds | ✓ PASS |
| DESC0017_POS003 | `DESC0017_POS003_all_oecd3_deletion_new_ids` | OECD3 | HK2025{Section}TC-DESC0017-POS003 + CorrDocRefId=D01 | Deletion — new DocRefIds + correct CorrDocRefIds | ✓ PASS |
| DESC0017_POS004 | `DESC0017_POS004_oecd1_different_suffix_pattern` | OECD1 | HK2025{Section}TC-D17-P4-{N:02d} | Different suffix style — all unique | ✓ PASS |
| DESC0017_POS005 | `DESC0017_POS005_oecd2_new_ids_second_correction` | OECD2 | HK2025{Section}TC-DESC0017-POS005 + CorrDocRefId=D01 | 2nd correction wave — again new unique DocRefIds | ✓ PASS |


### Negative Test Cases — DESC0017


| Test Case ID | Filename | Duplicate Section(s) | DocType | Duplicate DocRefId | # Violations | Expected |
|---|---|---|---|---|---|---|
| DESC0017_NEG001 | `DESC0017_NEG001_filinginfo_docrefid_duplicate` | FilingInfo only | OECD1 | HK2025FilingInfoTC-DESC0017-D01 (reused) | 1 | ✗ FAIL |
| DESC0017_NEG002 | `DESC0017_NEG002_generalsection_docrefid_duplicate` | GeneralSection only | OECD1 | HK2025GeneralSectionTC-DESC0017-D01 (reused) | 1 | ✗ FAIL |
| DESC0017_NEG003 | `DESC0017_NEG003_summary_jp_docrefid_duplicate` | Summary-JP only | OECD1 | HK2025Summary1TC-DESC0017-D01 (reused) | 1 | ✗ FAIL |
| DESC0017_NEG004 | `DESC0017_NEG004_jursection_jp_docrefid_duplicate` | JurisdictionSection-JP only | OECD1 | HK2025JurisdictionSection1TC-DESC0017-D01 (reused) | 1 | ✗ FAIL |
| DESC0017_NEG005 | `DESC0017_NEG005_utpr_docrefid_duplicate` | UTPRAttribution only | OECD1 | HK2025UTPRAttributionTC-DESC0017-D01 (reused) | 1 | ✗ FAIL |
| DESC0017_NEG006 | `DESC0017_NEG006_oecd2_correction_filinginfo_reuses_old_docrefid` | FilingInfo (OECD2) | OECD2 | D01_FI reused as DocRefId AND CorrDocRefId | 1 | ✗ FAIL |
| DESC0017_NEG007 | `DESC0017_NEG007_oecd3_deletion_summary_reuses_old_docrefid` | Summary-JP (OECD3) | OECD3 | D01_S1 reused as DocRefId — deletion must use new ID | 1 | ✗ FAIL |
| DESC0017_NEG008 | `DESC0017_NEG008_two_sections_fi_gs_duplicate` | FilingInfo + GeneralSection | OECD1 | D01_FI and D01_GS both reused | 2 | ✗ FAIL |
| DESC0017_NEG009 | `DESC0017_NEG009_two_sections_summary_jursection_duplicate` | Summary-JP + JurSect-JP | OECD1 | D01_S1 and D01_JS1 both reused | 2 | ✗ FAIL |
| DESC0017_NEG010 | `DESC0017_NEG010_all_7_sections_complete_resubmission` | All 7 sections | OECD1 | All 7 D01 DocRefIds reused — entire file is duplicate | 7 | ✗ FAIL |

---


## DESC0018 — CorrDocRefId References Unknown Record

<a name="desc0018"></a>

| Item | Detail |
|---|---|
| Rule ID | DESC0018 |
| Error Type | SevereError |
| Error Code | 60008 |
| Validation Rule | CorrDocRefId must reference an existing DocRefId in the DB |
| DB Required | **Y** |
| vs DESC0015 | DESC0015: record EXISTS in DB but wrong section type; DESC0018: record does NOT exist in DB |
| Total Files | 16 (1 STEP1 + 5 Positive + 10 Negative) |

> **Pre-condition**: `DESC0018_D01_STEP1_initial_all_oecd1.xml` creates D01 DocRefIds in DB


#### Pre-condition File

| Test Case ID | Filename | Expected |
|---|---|---|
| DESC0018_D01_STEP1 | `DESC0018_D01_STEP1_initial_all_oecd1.xml` | ✓ PASS (pre-cond) |


### Positive Test Cases — DESC0018


| Test Case ID | Filename | CorrDocRefId Value | Status in DB | Expected |
|---|---|---|---|---|
| DESC0018_POS001 | `DESC0018_POS001_all_oecd2_valid_corrdocrefids` | All = D01 values | ✓ Found in DB | ✓ PASS |
| DESC0018_POS002 | `DESC0018_POS002_all_oecd3_valid_corrdocrefids` | All = D01 values | ✓ Found in DB | ✓ PASS |
| DESC0018_POS003 | `DESC0018_POS003_filinginfo_oecd2_valid_corrref` | FI = D01_FI | ✓ Found in DB | ✓ PASS |
| DESC0018_POS004 | `DESC0018_POS004_summary_oecd3_valid_corrref` | Summary = D01_S1 | ✓ Found in DB | ✓ PASS |
| DESC0018_POS005 | `DESC0018_POS005_utpr_oecd2_valid_corrref` | UTPR = D01_UTPR | ✓ Found in DB | ✓ PASS |


### Negative Test Cases — DESC0018


| Test Case ID | Filename | Section | CorrDocRefId | Reason Not in DB | Expected |
|---|---|---|---|---|---|
| DESC0018_NEG001 | `DESC0018_NEG001_filinginfo_unknown_corrref` | FilingInfo | `HK2025FilingInfoTC-DESC0018-GHOST001` | Fabricated ghost ID — never submitted | ✗ FAIL |
| DESC0018_NEG002 | `DESC0018_NEG002_generalsection_unknown_corrref` | GeneralSection | `HK2025GeneralSectionTC-DESC0018-GHOST002` | Fabricated ghost ID | ✗ FAIL |
| DESC0018_NEG003 | `DESC0018_NEG003_summaryjp_unknown_corrref` | Summary-JP | `HK2025Summary1TC-DESC0018-GHOST003` | Fabricated ghost ID | ✗ FAIL |
| DESC0018_NEG004 | `DESC0018_NEG004_jurisdictionsectionjp_unknown_corrref` | JurisdictionSection-JP | `HK2025JurisdictionSection1TC-DESC0018-GHOST004` | Fabricated ghost ID | ✗ FAIL |
| DESC0018_NEG005 | `DESC0018_NEG005_utprattribution_unknown_corrref` | UTPRAttribution | `HK2025UTPRAttributionTC-DESC0018-GHOST005` | Fabricated ghost ID | ✗ FAIL |
| DESC0018_NEG006 | `DESC0018_NEG006_filinginfo_typo_suffix` | FilingInfo | `HK2025FilingInfoTC-DESC0018-D01**X**` | 1-char typo (D01X ≠ D01) | ✗ FAIL |
| DESC0018_NEG007 | `DESC0018_NEG007_generalsection_wrong_year_2024` | GeneralSection | `HK**2024**GeneralSectionTC-DESC0018-D01` | Wrong year (2024 vs 2025 in DB) | ✗ FAIL |
| DESC0018_NEG008 | `DESC0018_NEG008_summaryjp_wrong_jurisdiction_jp` | Summary-JP | `**JP**2025Summary1TC-DESC0018-D01` | Wrong jurisdiction prefix (JP vs HK) | ✗ FAIL |
| DESC0018_NEG009 | `DESC0018_NEG009_jurisdictionsectionjp_unsubmitted_version_d02` | JurisdictionSection-JP | `HK2025JurisdictionSection1TC-DESC0018-**D02**` | D02 never submitted (only D01 in DB) | ✗ FAIL |
| DESC0018_NEG010 | `DESC0018_NEG010_all_sections_unknown_corrdocrefids` | All 7 | `HK2025{Section}TC-DESC0018-UNKNXX (fabricated)` | All 7 ghost IDs — never submitted | ✗ FAIL × 7 |

---


## DESC0019 — CorrDocRefId References Outdated Version

<a name="desc0019"></a>

| Item | Detail |
|---|---|
| Rule ID | DESC0019 |
| Error Type | SevereError |
| Error Code | 60009 |
| Validation Rule | CorrDocRefId must reference the **latest** version of the record (not an outdated/invalidated version) |
| DB Required | **Y** — DB tracks version chain |
| vs DESC0018 | DESC0018: record NOT in DB; DESC0019: record IS in DB but has been superseded |
| Total Files | 18 (3 Pre-conditions + 5 Positive + 10 Negative) |

> **Version Chain** (submit in order):
> 1. STEP1: `DocRefId=D01` → D01 = LATEST
> 2. STEP2: `DocRefId=D02, CorrDocRefId=D01` → D01 = OUTDATED, D02 = LATEST
> 3. STEP3: `DocRefId=D03, CorrDocRefId=D02` → D02 = OUTDATED, D03 = LATEST
> 
> **After all 3 pre-conditions**: D03 = LATEST | D02 = outdated (1 version behind) | D01 = outdated (2 versions behind)


#### Pre-condition Files (submit in order)


| Test Case ID | Filename | DocTypeIndic | DocRefId | CorrDocRefId | Chain State After | Expected |
|---|---|---|---|---|---|---|
| DESC0019_D01_STEP1 | `DESC0019_D01_STEP1_initial_D01.xml` | OECD1 | D01 | None | D01 = LATEST | ✓ PASS |
| DESC0019_D02_STEP2 | `DESC0019_D02_STEP2_first_correction_D02.xml` | OECD2 | D02 | D01 | D01 = OUTDATED, D02 = LATEST | ✓ PASS |
| DESC0019_D03_STEP3 | `DESC0019_D03_STEP3_second_correction_D03.xml` | OECD2 | D03 | D02 | D02 = OUTDATED, D03 = LATEST | ✓ PASS |


### Positive Test Cases — DESC0019

All reference D03 (LATEST after all 3 pre-conditions)

| Test Case ID | Filename | Correcting Section | DocType | CorrDocRefId | Versions Behind | Expected |
|---|---|---|---|---|---|---|
| DESC0019_POS001 | `DESC0019_POS001_all_sections_corrref_D03_latest` | All sections | OECD2 | D03 (all sections) | 0 — current latest | ✓ PASS |
| DESC0019_POS002 | `DESC0019_POS002_filinginfo_oecd2_corrref_D03_latest` | FilingInfo | OECD2 | D03_FI | 0 — current latest | ✓ PASS |
| DESC0019_POS003 | `DESC0019_POS003_generalsection_oecd3_corrref_D03_latest` | GeneralSection | OECD3 | D03_GS | 0 — current latest | ✓ PASS |
| DESC0019_POS004 | `DESC0019_POS004_summary_oecd2_corrref_D03_latest` | Summary-JP | OECD2 | D03_S1 | 0 — current latest | ✓ PASS |
| DESC0019_POS005 | `DESC0019_POS005_utpr_oecd3_corrref_D03_latest` | UTPRAttribution | OECD3 | D03_UTPR | 0 — current latest | ✓ PASS |


### Negative Test Cases — DESC0019


| Test Case ID | Filename | Section | DocType | CorrDocRefId | Versions Behind | Reason | Expected |
|---|---|---|---|---|---|---|---|
| DESC0019_NEG001 | `DESC0019_NEG001_filinginfo_corrref_D02_outdated` | FilingInfo | OECD2 | D02_FI | 1 behind D03 | D02 invalidated by D03 | ✗ FAIL |
| DESC0019_NEG002 | `DESC0019_NEG002_generalsection_corrref_D02_outdated` | GeneralSection | OECD2 | D02_GS | 1 behind D03 | D02 invalidated by D03 | ✗ FAIL |
| DESC0019_NEG003 | `DESC0019_NEG003_summaryjp_corrref_D02_outdated` | Summary-JP | OECD3 | D02_S1 | 1 behind D03 | D02 invalidated by D03 | ✗ FAIL |
| DESC0019_NEG004 | `DESC0019_NEG004_jurisdictionsectionjp_corrref_D02_outdated` | JurisdictionSection-JP | OECD2 | D02_JS1 | 1 behind D03 | D02 invalidated by D03 | ✗ FAIL |
| DESC0019_NEG005 | `DESC0019_NEG005_utprattribution_corrref_D02_outdated` | UTPRAttribution | OECD3 | D02_UTPR | 1 behind D03 | D02 invalidated by D03 | ✗ FAIL |
| DESC0019_NEG006 | `DESC0019_NEG006_filinginfo_corrref_D01_outdated` | FilingInfo | OECD2 | D01_FI | 2 behind D03 | D01 invalidated by D02→D03 | ✗ FAIL |
| DESC0019_NEG007 | `DESC0019_NEG007_generalsection_corrref_D01_outdated` | GeneralSection | OECD2 | D01_GS | 2 behind D03 | D01 invalidated by D02→D03 | ✗ FAIL |
| DESC0019_NEG008 | `DESC0019_NEG008_summaryjp_corrref_D01_outdated` | Summary-JP | OECD3 | D01_S1 | 2 behind D03 | D01 invalidated by D02→D03 | ✗ FAIL |
| DESC0019_NEG009 | `DESC0019_NEG009_two_sections_FI_GS_corrref_D01_outdated` | FI + GS | OECD2 | D01_FI + D01_GS | 2 behind D03 | Both D01 values outdated — 2 violations | ✗ FAIL × 2 |
| DESC0019_NEG010 | `DESC0019_NEG010_all_7_sections_corrref_D01_outdated` | All 7 | OECD2 | All D01 values | 2 behind D03 | All 7 D01 values outdated — 7 violations | ✗ FAIL × 7 |

---


## DESC0020 — FilingInfo Deletion Without Deleting All Related Sections

<a name="desc0020"></a>

| Item | Detail |
|---|---|
| Rule ID | DESC0020 |
| Error Type | SevereError |
| Error Code | 60010 |
| Validation Rule | FilingInfo cannot be deleted (OECD3) unless ALL related sections are also deleted (OECD3) in the same message |
| DB Required | **Y** |
| Trigger Condition | `FilingInfo DocTypeIndic = OECD3` AND any of {GS, Summary, JurSect, UTPR} ≠ OECD3 |
| Total Files | 16 (1 STEP1 + 5 Positive + 10 Negative) |

> **Positions**: FI=pos1 | GS=pos2 | S-JP=pos3 | S-HK=pos4 | JS-JP=pos5 | JS-HK=pos6 | UTPR=pos7


#### Pre-condition File

| Test Case ID | Filename | Expected |
|---|---|---|
| DESC0020_D01_STEP1 | `DESC0020_D01_STEP1_initial_all_oecd1.xml` | ✓ PASS (pre-cond) |


### Positive Test Cases — DESC0020


| Test Case ID | Filename | FI | GS | S-JP | S-HK | JS-JP | JS-HK | UTPR | Rule Applied? | Expected |
|---|---|---|---|---|---|---|---|---|---|---|
| DESC0020_POS001 | `DESC0020_POS001_all_oecd3_complete_deletion` | OECD3 | OECD3 | OECD3 | OECD3 | OECD3 | OECD3 | OECD3 | Yes — satisfied | ✓ PASS |
| DESC0020_POS002 | `DESC0020_POS002_all_oecd2_correction_no_deletion` | OECD2 | OECD2 | OECD2 | OECD2 | OECD2 | OECD2 | OECD2 | No — FI≠OECD3 | ✓ PASS |
| DESC0020_POS003 | `DESC0020_POS003_fi_oecd2_others_oecd3_deletion` | OECD2 | OECD3 | OECD3 | OECD3 | OECD3 | OECD3 | OECD3 | No — FI≠OECD3 | ✓ PASS |
| DESC0020_POS004 | `DESC0020_POS004_fi_oecd2_mixed_oecd2_oecd3_others` | OECD2 | OECD3 | OECD2 | OECD3 | OECD2 | OECD3 | OECD2 | No — FI≠OECD3 | ✓ PASS |
| DESC0020_POS005 | `DESC0020_POS005_oecd3_all_sections_after_correction` | OECD3 | OECD3 | OECD3 | OECD3 | OECD3 | OECD3 | OECD3 | Yes — satisfied | ✓ PASS |


### Negative Test Cases — DESC0020

All have FilingInfo = OECD3 (deletion attempted) but at least one related section ≠ OECD3

| Test Case ID | Filename | FI | GS | S-JP | S-HK | JS-JP | JS-HK | UTPR | Sections Not Deleted | Expected |
|---|---|---|---|---|---|---|---|---|---|---|
| DESC0020_NEG001 | `DESC0020_NEG001_fi_oecd3_gs_not_deleted` | OECD3 | **OECD2** | OECD3 | OECD3 | OECD3 | OECD3 | OECD3 | GS | ✗ FAIL |
| DESC0020_NEG002 | `DESC0020_NEG002_fi_oecd3_both_summaries_not_deleted` | OECD3 | OECD3 | **OECD2** | **OECD2** | OECD3 | OECD3 | OECD3 | S-JP, S-HK | ✗ FAIL |
| DESC0020_NEG003 | `DESC0020_NEG003_fi_oecd3_both_jursections_not_deleted` | OECD3 | OECD3 | OECD3 | OECD3 | **OECD2** | **OECD2** | OECD3 | JS-JP, JS-HK | ✗ FAIL |
| DESC0020_NEG004 | `DESC0020_NEG004_fi_oecd3_utpr_not_deleted` | OECD3 | OECD3 | OECD3 | OECD3 | OECD3 | OECD3 | **OECD2** | UTPR | ✗ FAIL |
| DESC0020_NEG005 | `DESC0020_NEG005_fi_oecd3_one_summary_not_deleted` | OECD3 | OECD3 | **OECD2** | OECD3 | OECD3 | OECD3 | OECD3 | S-JP only | ✗ FAIL |
| DESC0020_NEG006 | `DESC0020_NEG006_fi_oecd3_one_jursection_not_deleted` | OECD3 | OECD3 | OECD3 | OECD3 | OECD3 | **OECD2** | OECD3 | JS-HK only | ✗ FAIL |
| DESC0020_NEG007 | `DESC0020_NEG007_fi_oecd3_gs_and_utpr_not_deleted` | OECD3 | **OECD2** | OECD3 | OECD3 | OECD3 | OECD3 | **OECD2** | GS + UTPR | ✗ FAIL |
| DESC0020_NEG008 | `DESC0020_NEG008_fi_oecd3_summaries_and_jursections_not_deleted` | OECD3 | OECD3 | **OECD2** | **OECD2** | **OECD2** | **OECD2** | OECD3 | S-JP, S-HK, JS-JP, JS-HK | ✗ FAIL |
| DESC0020_NEG009 | `DESC0020_NEG009_fi_oecd3_gs_s1_js1_utpr_not_deleted` | OECD3 | **OECD2** | **OECD2** | OECD3 | **OECD2** | OECD3 | **OECD2** | GS, S-JP, JS-JP, UTPR | ✗ FAIL |
| DESC0020_NEG010 | `DESC0020_NEG010_fi_oecd3_all_others_oecd2` | OECD3 | **OECD2** | **OECD2** | **OECD2** | **OECD2** | **OECD2** | **OECD2** | All 6 related sections | ✗ FAIL |

---


## DESC0021 — DocRefId Format Violation

<a name="desc0021"></a>

| Item | Detail |
|---|---|
| Rule ID | DESC0021 |
| Error Type | SevereError |
| Error Code | 60011 |
| Validation Rule | Each DocRefId must follow format: `{CC(2)}{Year(4)}{UID(1+)}` |
| DB Required | **N** — Format check only |
| vs DESC0011 | DESC0011 checks MessageRefId (`{CC}{Year}{CC}{UID}`); DESC0021 checks DocRefId (`{CC}{Year}{UID}` — simpler, no receiving CC) |
| Format Example | `HK2025FilingInfoTC-70005-001A1` |
| Minimum Length | 7 chars (2+4+1) |
| Total Files | 15 (5 Positive + 10 Negative) |

> **Positional format**: pos[1-2]=SendingCC | pos[3-6]=Year | pos[7+]=UniqueID


### Positive Test Cases — DESC0021


| Test Case ID | Filename | DocRefId Pattern | Min Length | Expected |
|---|---|---|---|---|
| DESC0021_POS001 | `DESC0021_POS001_standard_format_all_valid` | HK2025{Prefix}-DESC0021-POS001 (×7) | 24+ chars | ✓ PASS |
| DESC0021_POS002 | `DESC0021_POS002_minimal_uid_single_char` | HK2025A, HK2025B, ..., HK2025G (×7) | 7 chars (boundary min) | ✓ PASS |
| DESC0021_POS003 | `DESC0021_POS003_long_descriptive_uids` | HK2025{Prefix}-GIR-PROD-2025-FILING-XXXX (×7) | 40+ chars | ✓ PASS |
| DESC0021_POS004 | `DESC0021_POS004_date_embedded_uid` | HK2025{Prefix}-20251231{N:03d} (×7) | 30+ chars | ✓ PASS |
| DESC0021_POS005 | `DESC0021_POS005_compact_alphanumeric_uid` | HK2025D21P5{N:02d} (×7) | 14 chars | ✓ PASS |


### Negative Test Cases — DESC0021


| Test Case ID | Filename | Violating Section | Invalid DocRefId | Violation | pos[1-2] | pos[3-6] | pos[7+] | Expected |
|---|---|---|---|---|---|---|---|---|
| DESC0021_NEG001 | `DESC0021_NEG001_filinginfo_cc_has_digit` | FilingInfo | `H2025FilingInfoTC-...` | CC contains digit | ✗ H2 | ✗ 025F | ✓ | ✗ FAIL |
| DESC0021_NEG002 | `DESC0021_NEG002_generalsection_cc_lowercase` | GeneralSection | `hk2025GeneralSectionTC-...` | CC lowercase | ✗ hk | ✓ 2025 | ✓ | ✗ FAIL |
| DESC0021_NEG003 | `DESC0021_NEG003_summary_jp_year_2digits` | Summary-JP | `HK25Summary1TC-...` | 2-digit year | ✓ HK | ✗ 25Su | ✗ | ✗ FAIL |
| DESC0021_NEG004 | `DESC0021_NEG004_jursection_jp_no_uid` | JurisdictionSection-JP | `HK2025` | UID absent (6 chars) | ✓ HK | ✓ 2025 | ✗ (empty) | ✗ FAIL |
| DESC0021_NEG005 | `DESC0021_NEG005_utpr_totally_wrong_format` | UTPRAttribution | `TOTALLY-INVALID-UTPRAt-NEG005` | Completely malformed | ✓ TO | ✗ ALLY | ✓ | ✗ FAIL |
| DESC0021_NEG006 | `DESC0021_NEG006_filinginfo_cc_3chars_shifts_year` | FilingInfo | `HKK2025FilingInfoTC-...` | 3-char CC shifts year to K202 | ✓ HK | ✗ K202 | ✗ | ✗ FAIL |
| DESC0021_NEG007 | `DESC0021_NEG007_filinginfo_year_all_letters` | FilingInfo | `HKabcdFilingInfoTC-...` | Year is all letters (abcd) | ✓ HK | ✗ abcd | ✓ | ✗ FAIL |
| DESC0021_NEG008 | `DESC0021_NEG008_filinginfo_year_mismatch_reportingperiod` | FilingInfo | `HK2024FilingInfoTC-...` | Year 2024 ≠ ReportingPeriod 2025 | ✓ HK | ✗ 2024 | ✓ | ✗ FAIL |
| DESC0021_NEG009 | `DESC0021_NEG009_two_sections_FI_GS_both_invalid` | FI + GS | `FI:H2025... / GS:hk2025...` | FI:digit-CC; GS:lowercase-CC | ✗ H2 / ✗ hk | mixed | mixed | ✗ FAIL × 2 |
| DESC0021_NEG010 | `DESC0021_NEG010_all_7_docrefids_invalid_7_violations` | All 7 sections | `7 different violation types` | digit-CC, lower-CC, 2-digit-yr, 3-digit-yr, letter-yr, no-UID, totally-wrong | varied | varied | varied | ✗ FAIL × 7 |

---


## DESC0024 — OECD0 FilingInfo DocRefId Must Match Latest Version

<a name="desc0024"></a>

| Item | Detail |
|---|---|
| Rule ID | DESC0024 |
| Error Type | SevereError |
| Error Code | 60014 |
| Validation Rule | When FilingInfo DocTypeIndic = OECD0 (Resend), its DocRefId must be identical to the LATEST version of FilingInfo DocRefId in the DB |
| DB Required | **Y** |
| OECD0 Scope | ONLY FilingInfo can use OECD0 (unique to this section per GloBE schema) |
| OECD0 Behaviour | SAME DocRefId as latest (no CorrDocRefId) — differs from OECD2/3 which always use NEW DocRefId |
| Total Files | 17 (2 Pre-conditions + 5 Positive + 10 Negative) |

> **Pre-conditions** (submit in order):
> - STEP1: D01_FI created → D01_FI = LATEST
> - STEP2: OECD2 correction, D02_FI created → D01_FI = OUTDATED, D02_FI = LATEST
> 
> **OECD DocTypeIndic for FilingInfo Resend (OECD0)**:
> - `DocRefId` = **same** as latest version (D01_FI or D02_FI depending on DB state)
> - No `CorrDocRefId` element


#### Pre-condition Files (submit in order)


| Test Case ID | Filename | FI DocTypeIndic | FI DocRefId | DB State After | Expected |
|---|---|---|---|---|---|
| DESC0024_D01_STEP1 | `DESC0024_D01_STEP1_initial_all_oecd1.xml` | OECD1 | D01_FI | D01_FI = LATEST | ✓ PASS |
| DESC0024_D02_STEP2 | `DESC0024_D02_STEP2_correction_all_oecd2.xml` | OECD2 | D02_FI, CorrDocRefId=D01 | D01_FI = OUTDATED, D02_FI = LATEST | ✓ PASS |


### Positive Test Cases — DESC0024


| Test Case ID | Filename | Pre-conditions | FI DocTypeIndic | FI DocRefId Used | Latest in DB | Match | Expected |
|---|---|---|---|---|---|---|---|
| DESC0024_POS001 | `DESC0024_POS001_fi_oecd0_d01_correct_after_step1` | STEP1 only | OECD0 | `D01_FI` | `D01_FI` | ✓ | ✓ PASS |
| DESC0024_POS002 | `DESC0024_POS002_fi_oecd0_d01_others_oecd3_after_step1` | STEP1 only | OECD0 | `D01_FI` | `D01_FI` | ✓ | ✓ PASS |
| DESC0024_POS003 | `DESC0024_POS003_fi_oecd0_d01_gs_oecd2_others_oecd3_after_step1` | STEP1 only | OECD0 | `D01_FI` | `D01_FI` | ✓ | ✓ PASS |
| DESC0024_POS004 | `DESC0024_POS004_fi_oecd0_d02_correct_after_step2` | STEP1+STEP2 | OECD0 | `D02_FI` | `D02_FI` | ✓ | ✓ PASS |
| DESC0024_POS005 | `DESC0024_POS005_fi_oecd0_d02_all_oecd3_after_step2` | STEP1+STEP2 | OECD0 | `D02_FI` | `D02_FI` | ✓ | ✓ PASS |


### Negative Test Cases — DESC0024


| Test Case ID | Filename | Pre-conditions | FI DocRefId Used | Latest in DB | Mismatch Reason | Expected |
|---|---|---|---|---|---|---|
| DESC0024_NEG001 | `DESC0024_NEG001_fi_oecd0_unknown_brand_new_id` | STEP1 | `HK2025FilingInfoTC-DESC0024-UNKNOWN999` | `D01_FI` | Unknown ID never in DB | ✗ FAIL |
| DESC0024_NEG002 | `DESC0024_NEG002_fi_oecd0_d01_fi_typo` | STEP1 | `D01_FI + 'X' suffix (D01X)` | `D01_FI` | 1-char typo — D01X ≠ D01 | ✗ FAIL |
| DESC0024_NEG003 | `DESC0024_NEG003_fi_oecd0_wrong_section_d01_gs` | STEP1 | `D01_GS (GeneralSection's DocRefId)` | `D01_FI` | Wrong section's DocRefId | ✗ FAIL |
| DESC0024_NEG004 | `DESC0024_NEG004_fi_oecd0_wrong_year_in_id` | STEP1 | `HK2024FilingInfoTC-DESC0024-D01` | `D01_FI` | Wrong year (2024 vs 2025) | ✗ FAIL |
| DESC0024_NEG005 | `DESC0024_NEG005_fi_oecd0_totally_fabricated` | STEP1 | `COMPLETELY-FABRICATED-FILING-INFO-REF-001` | `D01_FI` | Fabricated ID not in DB | ✗ FAIL |
| DESC0024_NEG006 | `DESC0024_NEG006_fi_oecd0_d01_outdated_after_step2` | STEP1+STEP2 | `D01_FI (OUTDATED!)` | `D02_FI` | D01_FI superseded by D02 correction — most critical case | ✗ FAIL |
| DESC0024_NEG007 | `DESC0024_NEG007_fi_oecd0_d02_gs_wrong_section` | STEP1+STEP2 | `D02_GS (GeneralSection's D02)` | `D02_FI` | Wrong section DocRefId | ✗ FAIL |
| DESC0024_NEG008 | `DESC0024_NEG008_fi_oecd0_d01_utpr_wrong_section` | STEP1+STEP2 | `D01_UTPR (UTPRAttribution's D01)` | `D02_FI` | Wrong section DocRefId | ✗ FAIL |
| DESC0024_NEG009 | `DESC0024_NEG009_fi_oecd0_d03_fi_never_submitted` | STEP1+STEP2 | `D03_FI (D03 never submitted)` | `D02_FI` | D03 doesn't exist in DB yet (future version) | ✗ FAIL |
| DESC0024_NEG010 | `DESC0024_NEG010_fi_oecd0_new_unique_oecd2_style_id` | STEP1+STEP2 | `HK2025FilingInfoTC-DESC0024-NEG010` | `D02_FI` | Brand-new unique ID (correct for OECD2, wrong for OECD0) | ✗ FAIL |

---


## Summary Statistics


| DESC ID | Error Code | Error Type | DB Req | Pre-cond Files | Positive Files | Negative Files | Total Files |
|---|---|---|---|---|---|---|---|
| DESC0004 | 50005 | FileError | N | 0 | 10 | 31 | **41** |
| DESC0008 | 50009 | FileError | N | 0 | 10 | 15 | **25** |
| DESC0009 | 50010 | FileError | N | 0 | 5 | 15 | **20** |
| DESC0011 | 60001 | SevereError | N | 0 | 5 | 15 | **20** |
| DESC0012 | 60002 | SevereError | Y | 5 (STEP1) | 5 | 5 (STEP2) | **15** |
| DESC0013 | 60003 | SevereError | N | 0 | 5 | 10 | **15** |
| DESC0015 | 60005 | SevereError | Y | 1 | 5 | 10 | **16** |
| DESC0017 | 60007 | SevereError | Y | 1 | 5 | 10 | **16** |
| DESC0018 | 60008 | SevereError | Y | 1 | 5 | 10 | **16** |
| DESC0019 | 60009 | SevereError | Y | 3 | 5 | 10 | **18** |
| DESC0020 | 60010 | SevereError | Y | 1 | 5 | 10 | **16** |
| DESC0021 | 60011 | SevereError | N | 0 | 5 | 10 | **15** |
| DESC0024 | 60014 | SevereError | Y | 2 | 5 | 10 | **17** |
| **TOTAL** | | | | **~14** | **~85** | **~161** | **~260** |


### Test Case Coverage by Error Behaviour


| Coverage Area | Description |
|---|---|
| File-level threats | DESC0004 — Security content scanning (hyperlinks, JS, executables, null bytes) |
| Message metadata | DESC0008, DESC0009, DESC0011, DESC0012, DESC0013 — MessageSpec field validation |
| DocSpec format | DESC0021 — DocRefId format; DESC0011 — MessageRefId format |
| Correction chain | DESC0015, DESC0017, DESC0018, DESC0019, DESC0024 — CorrDocRefId + version chain |
| Deletion integrity | DESC0020 — FilingInfo deletion requires all related sections |
| DB-dependent | DESC0012, DESC0015, DESC0017, DESC0018, DESC0019, DESC0020, DESC0024 |
| Format-only (no DB) | DESC0004, DESC0008, DESC0009, DESC0011, DESC0013, DESC0021 |


### Test Execution Order (DB-Dependent Tests)


For DB-dependent test cases, pre-condition files **must** be submitted before test files:

| DESC | Required Pre-condition Sequence |
|---|---|
| DESC0012 | NEG00X_STEP1 → NEG00X_STEP2 (per scenario) |
| DESC0015 | D01_STEP1 → All POS/NEG files |
| DESC0017 | D01_STEP1 → All POS/NEG files |
| DESC0018 | D01_STEP1 → All POS/NEG files |
| DESC0019 | D01_STEP1 → D02_STEP2 → D03_STEP3 → All POS/NEG files |
| DESC0020 | D01_STEP1 → All POS/NEG files |
| DESC0024 | D01_STEP1 → D02_STEP2 (for POS004/005 + NEG006-010) |

---

*Document generated from GloBE XML test suite based on GLOBE_BASELINE_COMPLEX.xml | OECD GIR XML Schema v1.0*