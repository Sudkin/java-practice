# CA → HK GIR XML 測試檔說明（CTBP5005 · 44 個 Test Case）

## 1. 結論：最少 7 份 XML

44 個 test case 裡，**真正需要「XML 內容不同」的只有少數幾個**；其餘要嘛重複使用同一份 XML，要嘛只是改「打包 / 環境 / 設定」（損毀 zip、keystore、系統日期、空 Inbox……）。

會逼出「不同 XML」的因素只有下面 5 個，而且彼此不能合併：

| # | 因素 | 為什麼不能併進別的檔 | 對應檔案 |
|---|---|---|---|
| 1 | `MessageTypeIndic` = GIR101 還是 GIR102 | 這是**整份訊息**層級的欄位，一份檔只能有一個值（TC-030 需要 GIR102） | F4 |
| 2 | 新資料（OECD1 / OECD0）vs 更正（OECD2 / OECD3） | Status Message 規格 **60004**：同一份訊息不可混用新資料與更正 | F1、F2 vs F3 |
| 3 | 需要「先送過」的記錄才能寫 OECD0 / OECD2 / OECD3 | OECD0（resend）與 OECD2/3 的 `DocRefId` / `CorrDocRefId` 必須指向已送出的記錄（**60008 / 60014**），所以要有一份「先送出」的 F1 | F1 → F2 → F3 → F4 |
| 4 | XSD 不合格 | 要有一份會 Rejected 的檔（TC-019/023/024/038/042） | F5 |
| 5 | 寄件國非夥伴 / 資料年度超範圍 | 這兩個值都寫在 XML 內（`MessageSpec` 國碼、`MessageRefId` 年份），且兩個 TC 各自要隔離單一變數，所以要兩份 | F6、F7 |

**關鍵手法：一份 XML 內放多個 `GLOBEBody`（每個 `GLOBEBody` = 一個 `FilingInfo`）。**
XSD 允許 `GLOBEBody` 重複，而且 CTBP5005 的計數邏輯本來就是「逐個 FilingInfo 走訪」，TC-029/030 的測試資料也明說是「3 個 FilingInfo」。所以計數類的 5 個 TC（029–033）可以濃縮在 F2、F3、F4 三份裡。

> 補充：如果你們環境的「夥伴 / 資料年度」檢查其實是讀 CTS **metadata**（`TxCtry`、`TaxYr`），TC-009、TC-012 可以直接改 F1 的 metadata 來做，F6、F7 就不需要，最少可降到 5 份。我按文檔字面（讀 `MessageSpec` 與 `MessageRefId`）保留成 XML 內容不同的 7 份。

---

## 2. 七份 XML 總覽

**每份 XML 只有一個 Role**（一個申報單位）。F1–F4、F6 是 UPE（`GIR401`），F5、F7 是 DFE（`GIR402`）。F2、F3、F4 要重送或更正 F1 送過的記錄，申報單位必須是同一個，所以 F1–F4 這條鏈的 Role 都得是 UPE；DFE 放在互不相干的獨立檔案。

全部通過你上傳的 GloBE XSD 驗證（F5 除外，F5 是刻意做壞的）。「預期計數」是照文檔 §6、§7 的計數邏輯逐個 FilingInfo 算出來的。

| # | 檔名（＝MessageRefId） | MessageTypeIndic | GLOBEBody 組成 | XSD | 預期 GIR / Correction |
|---|---|---|---|---|---|
| F1 | `CA2025HKTC-UPE-OECD1-GIR101.xml` | GIR101 | B1：OECD1（含全部 5 種 section）<br>B2：OECD1（GeneralSection） | ✅ 通過 | **2 / 0** |
| F2 | `CA2025HKTC-UPE-OECD1-0-GIR101.xml` | GIR101 | B1：OECD1<br>B2：OECD1<br>B3：**OECD0** ＋ UTPRAttribution **OECD1**<br>B4：**OECD0**，無任何 section | ✅ 通過 | **2 / 1** |
| F3 | `CA2025HKTC-UPE-OECD2-3-GIR101.xml` | GIR101 | B1：**OECD2**（更正 F2-B1）<br>B2：**OECD3**（刪除 F2-B2，含其 GeneralSection） | ✅ 通過 | **0 / 2** |
| F4 | `CA2025HKTC-UPE-OECD2-GIR102.xml` | **GIR102** | B1、B2、B3：各一個 OECD2（更正 F1-B1、F1-B2、F3-B1） | ✅ 通過 | **0 / 3** |
| F5 | `CA2025HKTC-DFE-OECD1-GIR101-XSDERR.xml` | GIR101 | 單一 DFE body，注入 3 個 XSD 錯誤 | ❌ 刻意失敗 | Rejected，不計 |
| F6 | `AQ2025HKTC-UPE-OECD1-GIR101-NONPARTNER.xml` | GIR101 | 單一 UPE body，內容合格；寄件國 = **AQ** | ✅ 通過 | 不進入處理 |
| F7 | `CA2019HKTC-DFE-OECD1-GIR101-YEAR2019.xml` | GIR101 | 單一 DFE body，內容合格；資料年度 = **2019** | ✅ 通過 | 不進入處理 |

**建議送檔順序：F1 → F2 → F3 → F4**（後面的檔案引用前面檔案的 DocRefId）。CTBP5005 只做 XSD 驗證、不查 CorrDocRefId 是否存在，但照順序送，資料才是一致的。

---

## 3. 命名、日期與我做的假設

### 3.1 方向
- `TransmittingCountry = CA`、`ReceivingCountry = HK`。
- 你給的 HK→CA 範例整份做了 **HK ↔ CA 對調**：UPE 在 CA、CE 在 HK；`JurWithTaxingRights` 變成 CA；各處 `TIN issuedBy`、`ResCountryCode` 也跟著對調。
- `RecJurCode` 保持 HK（接收方）＋ CA；幣別維持範例的 `CAD`。

### 3.2 ID 格式（照你的例子）
- **MessageRefId**：`CA` + `2025` + `HK` + `TC-<ROLE>-OECD<n>-GIR101/102`，例如 `CA2025HKTC-UPE-OECD1-GIR101`。
- **DocRefId**：`CA2025` + `區塊名` + `同一個 TC 後綴`，例如 `CA2025FilingInfoTC-UPE-OECD1-GIR101-B1`。
  - 只有**多 body 的檔案**才加 `-B1`、`-B2`… 來保證唯一；單 body 的 F5/F6/F7 完全照你的格式（沒有 `-Bn`）。
  - 同一份 body 內 Summary、JurisdictionSection 沿用範例寫法（`Summary1` / `Summary2` / `JurisdictionSection1` / `JurisdictionSection2`）。
- **Role 只有 UPE / DFE 兩種，每份檔一個**：UPE = `GIR401`，DFE = `GIR402`（Designated Filing Entity）。你寫的 DPE，我用 schema 的名稱 DFE。`GIR403/404/405` 是本地申報角色，規格 60019 說這類 GIR 不會交換，所以沒有用。
- **同一份檔內所有 body 是同一個申報單位**（同名稱、TIN、Role），body 之間只差 DocRefId 與內容。
- 檔名名稱含多個 OECD 編號時，例如 `OECD1-0`、`OECD2-3`，表示該檔內同時有這幾種 DocTypeIndic。

### 3.3 日期規則

| 檔案 | Period Start–End | ChangeDate（GeneralSection） | Timestamp |
|---|---|---|---|
| F1 | 2025-01-01 ～ 2025-01-02 | 01-01、01-02 | 2025-12-31T12:00:00 |
| F2 | 2025-01-04 ～ 2025-01-05 | 01-04、01-05 | 2025-12-31T12:01:00 |
| F3 | 2025-01-07 ～ 2025-01-08 | 01-07、01-08 | 2025-12-31T12:02:00 |
| F4 | 2025-01-10 ～ 2025-01-11 | （無，見下方說明） | 2025-12-31T12:03:00 |
| F5 | 2025-01-13 ～ 2025-01-14 | 01-13、01-14 | 2025-12-31T12:04:00 |
| F6 | 2025-01-16 ～ 2025-01-17 | 01-16、01-17 | 2025-12-31T12:05:00 |
| F7 | 2019-01-19 ～ 2019-01-20 | 01-19、01-20 | 2019-12-31T12:06:00 |

- 每份間隔一天，Period 與 ChangeDate 一起跟著改（範例的兩個 CE 的 ChangeDate 本來就等於 Period 的 Start / End，我照這個關係推）。
- F4 只有 FilingInfo（更正 FilingInfo，不含 GeneralSection），所以沒有 ChangeDate 可改。
- **ElectionYear 沒有跟著改**：User Guide 規定這欄必須是「該年 1 月 1 日」，所以固定 `2025-01-01`（F7 是 `2019-01-01`）。
- **ReportingPeriod 固定 `2025-12-31`**：User Guide 規定是報告期最後一日，且要和 MessageRefId 的年份一致。
- **Timestamp** 只差分鐘，沒有差日子；如果你要連 Timestamp 也每份不同日，告訴我一聲改。
- **F7 全部日期改用 2019 年**（保留同樣的月日位置）。因為 Period 結束日不可晚於 ReportingPeriod（規格 60021），只改年份標籤、不改 Period 會自相矛盾。

### 3.4 兩個「刻意的非 CA 值」
- **F6 用 `AQ`（南極洲）當非夥伴**：它是合法 ISO 國碼（XSD 不會先擋掉），而且幾乎不可能被登記成夥伴。若你們環境有別的「已知非夥伴」代碼，把 F6 內的 `AQ` 換掉即可。
- **F7 用 2019 當超範圍年份**：早於支柱二開始，也不晚於現在（避免踩到 60003）。如果你們設定的 Start Year 早於 2019，改成別的年份即可。

---

## 4. 每份 XML 是怎麼設計的

### F1 — 基礎合格檔（`TC-UPE-OECD1-GIR101`，Role：UPE）
- **Role：UPE。** 兩個 body 是同一個申報單位。
- **B1**：FilingInfo + GeneralSection + Summary×2 + JurisdictionSection×2 + UTPRAttribution，全部 OECD1。內容就是你範例那份的對調版。
- **B2**：FilingInfo + GeneralSection，OECD1。它的另一個作用是提供 F2、F4 之後可以引用的第二筆已送出記錄。
- 用途：所有「一份正常的、會被 Accepted 的檔」的場景都用它。計數 GIR = 2（兩個 OECD1），Correction = 0。

### F2 — 計數檔：新資料 + 重送（`TC-UPE-OECD1-0-GIR101`，Role：UPE）
| Body | FilingInfo | Section | 對計數的貢獻 | 對應 TC |
|---|---|---|---|---|
| B1 | OECD1 | GeneralSection OECD1 | GIR +1 | 029 |
| B2 | OECD1 | GeneralSection OECD1 | GIR +1 | 029 |
| B3 | **OECD0**，`DocRefId` = F1-B1 的 FilingInfo | UTPRAttribution **OECD1**（新增一個 section） | Correction **+1**（規則 §7 第 3 條成立） | 032 |
| B4 | **OECD0**，`DocRefId` = F1-B2 的 FilingInfo | 無 | Correction **+0**（沒有任何 section 是 OECD1/11） | 033 |

合計：**GIR = 2、Correction = 1**。
OECD0 只能用在 FilingInfo（規格 60013），所以「OECD0 + 有 OECD1 的 section」的 section 只能選 Summary / JurisdictionSection / UTPRAttribution；GeneralSection 不行（60016）。我選了最短的 UTPRAttribution。

### F3 — GIR101 下的更正（`TC-UPE-OECD2-3-GIR101`，Role：UPE）
- **B1**：FilingInfo **OECD2**，`CorrDocRefId` = F2-B1 的 FilingInfo → Correction +1。
- **B2**：FilingInfo **OECD3**（刪除），`CorrDocRefId` = F2-B2 的 FilingInfo；同時把它的 GeneralSection 也用 OECD3 刪掉（規格 60010 要求刪 FilingInfo 就要刪光相關 section）→ Correction +1。
- 合計：**GIR = 0、Correction = 2**。因為 60004，這一份不能放 OECD1，所以獨立成一份。

### F4 — GIR102（`TC-UPE-OECD2-GIR102`，Role：UPE）
- 三個 body，各一個 FilingInfo OECD2，分別更正 F1-B1、F1-B2 和 F3-B1（B 的最新版本）。
- **每個 `CorrDocRefId` 都指向不同的、仍有效的記錄**（60006、60009 都不會觸發）。
- 合計：**GIR = 0、Correction = 3**（GIR102 下每個 FilingInfo 都 +1，與 DocTypeIndic 無關）。

### F5 — XSD 不合格（`TC-DFE-OECD1-GIR101-XSDERR`，Role：DFE）
單一 DFE body，其餘完全合格，只注入 3 個錯誤（檔內有 `DEFECT 1/2/3` 註解標示位置）：

| # | 錯誤 | 實際 XSD 錯誤訊息 |
|---|---|---|
| 1 | 拿掉必填的 `<FAS>` | `Element 'Currency': This element is not expected. Expected is ( FAS )` |
| 2 | `Role` = `GIR499`（不在列舉內） | `The value 'GIR499' is not an element of the set {GIR401…GIR405}` |
| 3 | `AdjustedFANIL/Total` = `2146463.5`（欄位要整數） | `'2146463.5' is not a valid value of the atomic type 'xs:integer'` |

用多個錯誤是為了讓 TC-024 的「field-level 錯誤」有多筆可以看。

### F6 — 非夥伴（`TC-UPE-OECD1-GIR101-NONPARTNER`，Role：UPE）
內容是一份合格的 UPE 檔，但整份的寄件國改成 `AQ`（`TransmittingCountry`、`FilingCE/ResCountryCode`、`TIN issuedBy` 等都一致改成 AQ，所以不會因為國碼互相矛盾而混進別的失敗原因）。

### F7 — 資料年度超範圍（`TC-DFE-OECD1-GIR101-YEAR2019`，Role：DFE）
內容是一份合格的 DFE 檔，但年份是 2019：`MessageRefId` = `CA2019HK…`、`ReportingPeriod` = 2019-12-31，所有日期都在 2019。

---

## 5. 44 個 Test Case 怎麼做

**通用的打包步驟**（每個 TC 都會用到，下面不重複）：把 XML 依你們既有流程簽章 / 加密 / 壓縮成 zip，檔名要符合 `*GIR*.zip`（例：`CA_GIR_20250101T080000000Z_xxxx.zip`），並附上對應的 CTS metadata（`TxCtry=CA`、`RxCtry=HK`、`TaxYr=2025`…）；放進 `\data\cts\Inbox\`，等排程或手動觸發。

### B1. Batch 觸發與檔案掃描

| TC | 用哪份 | 怎麼做 | 驗證重點 |
|---|---|---|---|
| 001 | F1 | 在週一到週五 08:00 / 12:00 / 16:00 之前放好 F1 的 zip，等排程 | Job 自動起跑，F1 走完整流程並 Accepted |
| 002 | F1 | 在非排程時間（例如 10:30）手動 ad-hoc 觸發 | 行為與 001 相同 |
| 003 | F1 ＋ 兩個干擾檔 | Inbox 放 F1 zip、`CA_REPORT_2025.zip`、`CA_GIR_2025.txt`（干擾檔內容隨意，不需要新 XML） | 只有 `*GIR*.zip` 被處理，另外兩個被忽略 |
| 004 | 無 | 清空 Inbox 後觸發 | 正常結束，無錯誤 |
| 005 | F1、F2、F3 | 三份各自打包成**不同檔名**的 zip，一次放進 Inbox | 三份都在同一輪處理完。⚠️ 文檔寫「來自不同夥伴」，但你只要 CA→HK，所以用三份不同的 CA 檔代替，驗證的是迴圈邏輯 |

### B2. 重複檔名檢查

| TC | 用哪份 | 怎麼做 | 驗證重點 |
|---|---|---|---|
| 006 | F1 | 先讓 F1 正常處理完一次；再把**同檔名**的 zip 放回 Inbox | 移到 `Inbox_duplicated`，該檔停止處理（不需要新 XML） |
| 007 | F1 | 用全新檔名放進 Inbox | 不被當成重複，繼續解壓與驗證 |

### B3. 夥伴與日期 / 年度

| TC | 用哪份 | 怎麼做 | 驗證重點 |
|---|---|---|---|
| 008 | F1 | CA 已登記為夥伴、系統日期在 Start/End Date 內 | 繼續進入解密 |
| 009 | **F6** | 寄件國 AQ 不在夥伴表 | **不解密**，不繼續處理 |
| 010 | F1 | **不改 XML**：把 CA 夥伴的 Incoming GIR Start/End Date 設定改掉（或調系統日期），讓今天落在窗外 | 依日期窗規則不被接受 |
| 011 | F1 | 資料年度 2025（`MessageRefId` 的 `CA2025HK…`，metadata `TaxYr=2025`）在 Start/End Year 內 | 繼續處理 |
| 012 | **F7** | 資料年度 2019，metadata `TaxYr` 也設 2019 | 依年度規則不當成範圍內 GIR 處理 |

### B4. 解密與憑證

| TC | 用哪份 | 怎麼做 | 驗證重點 |
|---|---|---|---|
| 013 | F1 | keystore 內有 CA 的公開憑證 | 解密成功，進入 XSD 驗證 |
| 014 | F1 的損毀副本 | 用 F1 正常打包後，把加密檔截斷或改幾個 byte | 移到 `Inbox_invalid`，`ValidationResult='Rejected'`（不需要新 XML） |
| 015 | F1 | 從 keystore 移除 CA 公開憑證後處理 F1 | 無法解密，依規則視為無效 / Rejected |

### B5. 威脅掃描

| TC | 用哪份 | 怎麼做 | 驗證重點 |
|---|---|---|---|
| 016 | F1 | 乾淨檔 | 通過，繼續 XSD 驗證 |
| 017 | F1 | 打包階段在檔案內附加業界標準的 **EICAR 測試字串**（我**沒有**放進提供的 XML，避免你們的防毒直接攔截或誤刪這份 XML） | 威脅被偵測，依規則停止 / 隔離，不當成 Accepted 寫入 |

### B6. XSD 驗證

| TC | 用哪份 | 怎麼做 | 驗證重點 |
|---|---|---|---|
| 018 | F1（F2–F4 皆可） | 正常送檔 | `ValidationResult='Accepted'` |
| 019 | **F5** | 送檔 | `ValidationResult='Rejected'`，並記錄上面 3 個 schema 錯誤 |

### B7. DB — Accepted

| TC | 用哪份 | 怎麼做 | 驗證重點 |
|---|---|---|---|
| 020 | F1 | 送檔後查 DB | `CTS_DATA_PACKET`（`MSG_TYPE='GIR'`）、`CTS_TX_REC`、`GIR_*` 都有寫入，並產生 accept status message |
| 021 | F1（＋F5 對照） | 對照 F1 的 `GIR_*` 各表筆數與 XML 內記錄數（F1 有 2 個 FilingInfo、1 個 UPE 全套 section、1 個 GeneralSection…）。再送 F5 看 `GIR_*` 是否**完全沒有**寫入 | 只有通過 XSD 的記錄入庫。⚠️ 文檔寫的「Accepted 但混有無效記錄」在實際流程不會出現（XSD 不合格整份就 Rejected），所以用「F1 全入庫 ＋ F5 全不入庫」來驗證這條規則 |
| 022 | F1 ＋ 其 metadata | 準備已知的 metadata 值（`TxCtry=CA`、`RxCtry=HK`、`TaxYr=2025`、`FileRevInd`、`OriTxId`、`SenderEmail`…） | `CTS_DATA_PACKET.META_*` 與 metadata 一一對應 |

### B8. DB — Rejected

| TC | 用哪份 | 怎麼做 | 驗證重點 |
|---|---|---|---|
| 023 | **F5** | 送檔後查 DB | 有 `CTS_DATA_PACKET`、message spec、transmission 資料；**沒有** `GIR_*` data file 記錄 |
| 024 | **F5**（F1 對照） | 查 4 張錯誤表 | F5：`CTS_FILE_ERR`、`CTS_REC_ERR`、`CTS_ERR_FIELD`、`CTS_ERR_DOC_REF_ID` 有記錄；F1：這幾張是空的 |

### B9. Status Message 產生

| TC | 用哪份 | 怎麼做 | 驗證重點 |
|---|---|---|---|
| 025 | F1 ＋ F5 | 各取產出的 `GIRMessageStatus` XML，用 status message XSD 驗證 | 兩種結果（Accepted / Rejected）的狀態訊息都符合 schema |
| 026 | F1 | 查 DB | `CTS_DATA_PACKET`（`MSG_TYPE='GIRMessageStatus'`、`ZIP_FILENAME=NULL`）＋ `CTS_STS_MSG`，`SGD_STS='P'` |
| 027 | F1 | 檢查 `STS_MSG_REF_ID` 的格式 | 格式 `'Status'+HK+<Reporting Year>+<Receiving Country>+'-'+<yyyyMMddHHmmss>`。⚠️ TC 寫的是 Reporting Year = 2026，這批檔案是 2025，預期值以 2025 計；如果一定要 2026，需另外一份 2026 年度的檔（且要落在你們的 Start/End Year 內）。另外，這份狀態訊息是回給 CA 的，Receiving Country 應該是 CA 還是 HK，文檔沒寫清楚，建議向 BA 確認 |
| 028 | F1 | 檢查 `\data\in\status_out\pending\` | 有 `<MessageRefId>.xml` 與 `<MessageRefId>.metadata.xml` |

### B10. GIR / Correction 計數

| TC | 用哪份 | 怎麼做 | 預期 |
|---|---|---|---|
| 029 | **F2** | 送 F2，看 GIR 計數 | **GIR = 2**（B1、B2 是 OECD1；B3、B4 是 OECD0，不計入） |
| 030 | **F4** | 送 F4（GIR102、3 個 FilingInfo） | **Correction = 3**，GIR = 0 |
| 031 | **F3** | 送 F3（GIR101 + OECD2 + OECD3） | 每個 FilingInfo +1 → **Correction = 2**，GIR = 0 |
| 032 | **F2 的 B3** | F2 內 B3 是 OECD0 + UTPRAttribution OECD1 | 這個 FilingInfo 讓 Correction **+1** |
| 033 | **F2 的 B4** | F2 內 B4 是 OECD0 且沒有任何 OECD1/11 的 section | 這個 FilingInfo **不增加** Correction。F2 整份 Correction 合計 = 1（只來自 B3） |
| 034 | F2（F3、F4 補驗） | 送檔後查 `GIR_MSG_SPEC` | F2：`GIR_CNT=2`、`AMEND_CNT=1`（兩個值都非零，最容易看出 SP 有沒有更新對）；F3：0 / 2；F4：0 / 3 |

### B11. 檔案移動

| TC | 用哪份 | 怎麼做 | 驗證重點 |
|---|---|---|---|
| 035 | F1（Accepted）＋ F5（Rejected） | 各送一次 | 兩者的 zip 都在 `\data\cts\Inbox_recv\` |
| 036 | F1 | 送檔後看資料夾 | 解壓資料夾在 `\data\in\processed\{ZIP Filename}\` |

### B12. 電郵通知

| TC | 用哪份 | 怎麼做 | 驗證重點 |
|---|---|---|---|
| 037 | F1 | 送檔後收信 | 主旨為「…containing no errors」，內容 `Result: ACCEPTED`，提到 CTLQ5003 |
| 038 | **F5** | 送檔後收信 | 主旨為「…containing file error(s)」，`Result: REJECTED`。⚠️ TC 寫 `Error Code: 50002`，但 Status Message 規格中 **50002 = 檔案無法解密**，XSD 驗證失敗是 **50007**。要看到 50002，請改用 014 的損毀檔；F5 預期會顯示 50007 |
| 039 | F1 的損毀 zip | 把 F1 的 zip 弄成無法解壓的壞檔（與 014 的「加密壞」區分），送檔 | 主旨為「…unsuccessful processing…」，內容有 Country / Filename / Reason。具體哪類算 fatal，以 BA 的定義為準 |
| 040 | F1 ＋ F5 | 同一輪放兩個檔 | 兩種結果都各發一封通知信給指定收件人 |

### B13. 端到端與負面路徑

| TC | 用哪份 | 怎麼做 | 驗證重點 |
|---|---|---|---|
| 041 | F1 | 全部條件都正常 | Accepted → DB 寫入、status message、檔案移動、計數更新、Accepted 信；**錯誤表為空** |
| 042 | **F5** | 夥伴、日期、解密都正常，只有 XSD 錯 | Rejected → header + 錯誤表寫入，無 data file 記錄，Rejected status message + Rejected 信 |
| 043 | F1 的損毀副本 | 同 014 | 移到 `Inbox_invalid`，`Rejected`，batch 不崩潰 |
| 044 | F1（重送）＋ F1 損毀副本 ＋ F2 | 前提：F1 已處理過一次。同一輪放入：F1 同檔名（重複）、F1 損毀副本（解密失敗）、F2（合格） | 重複 → `Inbox_duplicated`；損毀 → `Inbox_invalid`＋Rejected；F2 → Accepted；整輪跑完並發信 |

---

## 6. 需要你留意 / 確認的地方

1. **Role 分配**：F1–F4、F6 為 UPE，F5、F7 為 DFE。Role 對 44 個 TC 沒有影響，DFE 檔純粹是角色變化。要調整哪份用哪個 Role，只要它不在 F1–F4 這條引用鏈裡就可以改。F4 的三個 body 只更正 FilingInfo、沒有 GeneralSection，所以規格 60022（UPE 的 TIN 要對得上 UPE 資料）在這份檔無從比對；CTBP5005 只做 XSD 驗證，不受影響。
2. **AQ、2019 是我挑的測試值**（見 3.4），視你們夥伴表與 Start/End Year 設定調整。
3. **OECD10–13（測試碼）沒有使用**：它們在計數邏輯裡和 OECD1–3 走同一條判斷，屬於同一個等價類；而且規格 50008 / 50009 說明 live 環境收到測試碼會被拒，容易和你要測的東西混在一起。
4. **OECD0 / OECD2 / OECD3 的 FilingInfo 也套用該檔自己的 Period 日期**（依你「每份日子不同」的規則），所以和它所引用的原記錄的日期不一樣。CTBP5005 只做 XSD 驗證，不比對內容，不影響測試結果。
5. **已做的驗證**：全部 XML 用你提供的 XSD 驗證（F1–F4、F6、F7 通過；F5 正好報出 3 個預期錯誤）；MessageRefId 無重複；每個 `CorrDocRefId` 都指向存在的 DocRefId；並用文檔 §6、§7 的計數邏輯逐檔算過預期計數（與上表一致）。
