# TC-CTBP5005-032 ~ 037 測試 XML

全部以 ES 版範例檔為基底,並已用 `GLOBEXML_v1_0.xsd`(Part F)逐一驗證通過。
下表的「基底 A」= 你先前的 `GLOBE_OECD_ES.xml`(GIR101、全部 OECD1,需已先成功送出)。

## 建議執行順序(同一份基底 A 上連續執行)

| 順序 | 檔案 | MessageTypeIndic | FilingInfo | 其他區塊 | CorrDocRefId / 引用的 DocRefId | 預期計數 |
|---|---|---|---|---|---|---|
| 0 | `GLOBE_OECD_ES.xml`(先前檔案) | GIR101 | OECD1 | 全部 OECD1 | 無 | 基底 |
| 1 | TC-032 | GIR101 | OECD0 | 無 | FilingInfo DocRefId 沿用基底 A(OECD0 必須等於最新版,不可有 Corr) | GIR 不加、Correction 不加 |
| 2 | TC-036 | GIR101 | OECD0 | 全部區塊 OECD0(照測試案例原文) | 各區塊 DocRefId 沿用基底 A | 不算 Correction |
| 3 | TC-035b / c / d | GIR101 | OECD0 | Summary / JurisdictionSection / UTPRAttribution 各一個 OECD1(新 DocRefId) | 無 Corr | Correction +1 |
| 3 | TC-035a | GIR101 | OECD0 | GeneralSection OECD1 | 無 Corr | 預期 Correction +1,但見下方注意 |
| 4 | TC-033 | **GIR102** | OECD0 | GeneralSection OECD2 | Corr = `ES2025GeneralSectionTC-CTBP5005-UPE-HK-30155093-02112026A` | Correction +1 |
| 5 | TC-037 | GIR101 | body1、body2:OECD1(新 FilingInfo + GeneralSection);body3:OECD0 | body3 另帶一個新 Summary OECD1 | body3 FilingInfo 沿用基底 A | GIR_CNT = 2、AMEND_CNT = 1 |
| 6 | TC-034a | GIR101 | **OECD2** | 無 | Corr = `ES2025FilingInfoTC-CTBP5005-UPE-HK-30155093-02112026A` | Correction +1 |
| 獨立 | TC-034b_00_setup → TC-034b | GIR101 | **OECD3** | 全部 7 筆 OECD3 | 見下 | Correction +1 |

TC-034a 會讓 FilingInfo 的「最新版」變成新的 DocRefId,所以放在最後。
TC-034b 刪除 FilingInfo 時,必須同時刪除所有關聯區塊(OECD 規則 60010)。為了不依賴其他案例的狀態,我另外做了獨立基底 B(TIN 全部改成 30155102,和基底 A 互不影響):先送 `TC-034b_00_setup`,再送 `TC-034b`,後者每一筆的 CorrDocRefId 都指向基底 B 對應的 DocRefId。

## DocRefId / MessageRefId 命名

- MessageRefId:`ES2025HKTC-CTBP5005-<案例編號>-UPE-30155093-02112026A`(符合「送出國+年度+收件國+唯一碼」)。
- 新增 / 更正 / 刪除記錄的 DocRefId:`ES2025<區塊>TC-CTBP5005-<案例編號>-UPE-HK-30155093-02112026A`。
- 兩者都必須全球唯一(重複會觸發 60002 / 60007)。重送同一個檔案時,請把結尾的 `02112026A` 改成新的值。
- Schema 的 MessageSpec 沒有 CorrMessageRefId,所以 GIR102 只需要填 DocSpec 裡的 CorrDocRefId。

## 需要你確認的地方

1. **TC-035a**:FilingInfo = OECD0 時,GeneralSection 不可為 OECD1(規則 60016,屬於會退件的嚴重錯誤)。所以這個檔案很可能被 HK 退件,Correction 計數也就不會被測到。要測 check 3,建議用 035b / c / d。
2. **TC-036**:測試案例寫「各區塊都是 OECD0」,但 OECD0 只允許用在 FilingInfo(規則 60013)。我照原文做了。如果被 60013 退件,可改用 TC-032 的檔案(只有 FilingInfo OECD0、沒有任何區塊),同樣符合「沒有任何區塊是 OECD1 / OECD11」。
3. **GIR101 搭配 FilingInfo OECD2 / OECD3**(TC-034):規格書說 GIR101 只含新資料,但測試案例本來就要這種組合。我沒有在 Schema Reference 裡找到會直接擋它的規則,不過仍請以 HK 實際回覆為準。
4. **TC-037** 裡 body1、body2 的 FilingInfo / GeneralSection 把 TIN 換成 30155111、30155112(NameMNE 為 TSETEBOLG037A / B),因為規則 60022 要求 FilingCE 的 TIN 必須出現在 UPE 清單裡。測試案例 SQL 內的 `CA2025HK202609300001` 和 ZIP 檔名請依實際送出的檔案調整。
5. 基底檔的 JurisdictionSection(HK)裡 AdjustedFANIL Total = 2,146,463,但 FANIL 加上 MainEntityPEandFTE 的 Additions 500,000 應該是 2,646,463(規則 60028)。如果 HK 有實作這條,基底檔就會被退件,後面的案例都會受影響。
