# TC-SEL-001 ~ TC-SEL-009 測試資料 XML 說明

依《CS501_CTBP5001_TestCases_攻略.md》第 1 組「Record Selection — 待交換記錄篩選條件」與
`501.md`、`CS501_CTBP5001_TestCases_Merged_with_Mapping.xlsx` 整理，並比照使用者提供的
`CTS-01CA.xml` 格式（GLOBEXML v1.0, `urn:oecd:ties:globe:v2`）產生。

每個檔案代表一筆**待灌入測試環境的「原始 GIR 申報檔」**（GIR101/新申報），
用來作為 CTBP5001 萃取程式「待交換記錄篩選」測試的前置資料。
檔案開頭以 XML 註解記載：對應測試案例、測試目的、關鍵值（TIN／接收國／RPT_YR）、
需另於資料庫設定的前置條件（狀態／通知／傳送旗標等，屬於申報處理或傳輸流程寫入的結果，
不屬於本 XML 內容本身），以及預期結果。

| 測試案例 | 檔案 | FilingCE TIN | 接收國 | RPT_YR | 情境重點 |
|---|---|---|---|---|---|
| TC-SEL-001 | TC-SEL-001.xml | T111 | ID | 2025 | Accepted + Active，從未傳送 → 基準情境，應被萃取 |
| TC-SEL-002 | TC-SEL-002.xml | T222 | ID | 2025 | DB 狀態切換為 Pending / Rejected → 應被排除 |
| TC-SEL-003 | TC-SEL-003.xml | T223 | ID | 2025 | 另需灌入 NTFC Error/Warning 通知 → 應被排除 |
| TC-SEL-004 | TC-SEL-004.xml | T224 | ID | 2025 | 另需灌入 CTS_TX_REC.TX_STS='T' → 應被排除（已傳送） |
| TC-SEL-005 | TC-SEL-005.xml | T551 | ID | 2025 | 接收國在生效窗口內（IS_PARTNER='Y'）→ 應被萃取 |
| TC-SEL-006 | TC-SEL-006.xml | T561 | IE | 2025 | 接收國窗口外（需先調整 IE 生效日期）→ 應被排除 |
| TC-SEL-007 | TC-SEL-007a.xml（2024）+ TC-SEL-007b.xml（2025） | T444 | ID | 2024/2025 | 2024 已傳送、TRANSMISSION_FLAG='Y' 尚未回覆 → 2025 應被排除 |
| TC-SEL-008 | TC-SEL-008a.xml（T555）+ TC-SEL-008b.xml（T666） | T555/T666 | ID | 2025 | 相同接收國/年度、不同 TIN → 應各自產生獨立檔案 |
| TC-SEL-009 | TC-SEL-009a/b/c.xml | T555(ID)、T555(CA)、T666(ID) | ID/CA | 2025 | 跨 TIN／跨接收國組合 → SQL7(V_EXT) 應為唯一權威清單 |

## 使用方式

1. 將對應檔案依測試案例灌入 / 送入測試環境的申報處理流程，使其在資料庫產生
   `PTP_ENC.RTN`（STATUS/IS_ACTIVE）等記錄。
2. 依各檔案註解中列出的「前置條件」，於資料庫額外設定狀態、通知或傳送旗標
   （這些欄位是系統處理結果，無法單靠 XML 內容觸發，需要測試者手動灌入或跑過對應流程）。
3. 執行 CTBP5001（Auto 或 Ad-hoc 皆可），再查詢 SQL7（V_EXT）或檢視輸出 XML，
   核對是否符合各案例的「預期結果」。

## 共用慣例

- 所有檔案皆為 `MessageTypeIndic=GIR101`（全新申報），`FilingInfo.DocSpec.DocTypeIndic=OECD1`。
- `TransmittingCountry`/`ReceivingCountry` 皆為 `HK`（申報人向香港稅務機關遞交的原始申報）。
- 環境僅有 ID、CA、IE 三個可用接收國（IE 為可調整生效期間的邊界測試接收國）。
- 金額、稅率等數值皆為測試用假資料，未特別對應真實運算邏輯（此為 Record Selection 篩選測試，
  非 XML 產出/運算邏輯測試，相關測試已分屬攻略文件的其他分組）。
- FilingCE Role 一律為 `GIR401`（UPE 申報）。
